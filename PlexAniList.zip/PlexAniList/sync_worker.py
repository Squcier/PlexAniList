"""
Worker de synchronisation : tourne dans un thread de fond, poll l'API Plex,
détecte les épisodes qui dépassent le seuil de progression, et met à jour
AniList via GraphQL.

Comportements notables (voir aussi les Paramètres) :
- Une même paire (titre, épisode) n'est envoyée qu'une seule fois à AniList :
  si l'utilisateur reste en pause au-dessus du seuil pendant plusieurs cycles
  de poll, on ne spamme pas la mutation à chaque fois.
- Les sessions qui ne sont pas des épisodes de série (films, clips) sont
  ignorées : on ne veut synchroniser que des animes suivis épisode par épisode.
- Les erreurs répétitives (mapping manquant, token invalide, etc.) ne sont
  journalisées qu'une fois par fenêtre de temps pour ne pas noyer l'historique.
- Les titres marqués "ignore" dans le mapping sont sautés silencieusement.
"""

import threading
import time
import traceback
from datetime import datetime, timedelta

from models import db, Library, Mapping, SeasonMapping, SyncHistory, Setting, SeasonSyncTarget
from plex_client import get_sessions, PlexError
from anilist_client import update_progress, AniListError
import episode_resolver

# Fenêtre minimale entre deux journalisations d'une même erreur récurrente
# (ex: "aucun mapping pour ce titre", token invalide, etc.)
ERROR_LOG_COOLDOWN = timedelta(minutes=15)
HISTORY_LIMIT = 10000


def _prune_history():
    """Conserve les 10 000 événements les plus récents."""
    cutoff = (db.session.query(SyncHistory.id)
              .order_by(SyncHistory.id.desc()).offset(HISTORY_LIMIT).limit(1).scalar())
    if cutoff is not None:
        SyncHistory.query.filter(SyncHistory.id <= cutoff).delete(synchronize_session=False)
        db.session.commit()


def _recently_logged(titre, message):
    """Évite de spammer SyncHistory avec la même erreur à chaque poll."""
    cutoff = datetime.utcnow() - ERROR_LOG_COOLDOWN
    existing = (
        SyncHistory.query
        .filter_by(titre=titre, statut="erreur", message=message)
        .filter(SyncHistory.date >= cutoff)
        .first()
    )
    return existing is not None


def _log_error_throttled(titre, episode, message):
    if _recently_logged(titre, message):
        return
    db.session.add(SyncHistory(titre=titre, episode=episode, statut="erreur", message=message))
    db.session.commit()




class SyncWorker(threading.Thread):
    def __init__(self, app):
        super().__init__(daemon=True)
        self.app = app
        self._pause = threading.Event()
        self._pause.set()  # Event "set" = worker actif dès le démarrage (comportement historique de l'app)
        self._stop = threading.Event()
        self._last_run = None
        self._last_error = None

    # --- Contrôle externe ---
    def pause(self):
        self._pause.clear()

    def resume(self):
        self._pause.set()

    def is_paused(self):
        return not self._pause.is_set()

    def stop(self):
        self._stop.set()
        self._pause.set()  # débloquer un éventuel wait()

    def status(self):
        return {
            "running": not self._stop.is_set(),
            "paused": self.is_paused(),
            "last_run": self._last_run,
            "last_error": self._last_error,
        }

    # --- Boucle principale ---
    def run(self):
        while not self._stop.is_set():
            # Attente active si en pause
            while self._pause.is_set() is False and not self._stop.is_set():
                time.sleep(1)
            if self._stop.is_set():
                return

            try:
                self._tick()
                with self.app.app_context():
                    _prune_history()
                self._last_run = time.strftime("%Y-%m-%d %H:%M:%S")
                self._last_error = None
            except Exception as e:
                self._last_error = f"{type(e).__name__}: {e}"
                # on log dans l'historique pour visibilité (mais pas à chaque poll si l'erreur persiste)
                with self.app.app_context():
                    try:
                        if not _recently_logged("(worker)", self._last_error):
                            db.session.add(SyncHistory(
                                titre="(worker)",
                                episode=None,
                                statut="erreur",
                                message=self._last_error + "\n" + traceback.format_exc()[:500],
                            ))
                            db.session.commit()
                    except Exception:
                        pass

            # Attente jusqu'au prochain poll (le contexte app est requis pour lire Setting)
            with self.app.app_context():
                interval = int(Setting.get("poll_interval", "30") or 30)
            # attente interruptible
            for _ in range(interval):
                if self._stop.is_set():
                    return
                time.sleep(1)

    def _tick(self):
        """Une passe de synchronisation."""
        with self.app.app_context():
            plex_url = Setting.get("plex_url", "")
            plex_token = Setting.get("plex_token", "")
            threshold = float(Setting.get("progress_threshold", "85") or 85)
            sync_on_pause = Setting.get("sync_on_pause", "1") == "1"
            auto_complete = Setting.get("auto_complete", "1") == "1"

            if not plex_token:
                raise PlexError("Aucun token Plex configuré")

            sessions = get_sessions(plex_url, plex_token)
            active_library_ids = {l.id_plex for l in Library.query.filter_by(activee=True).all()}
            if not active_library_ids:
                return

            for s in sessions:
                # On ne synchronise que des épisodes de série (pas les films/clips/musique).
                if s.get("type") and s["type"] != "episode":
                    continue
                if s["progress"] < threshold:
                    continue
                if not sync_on_pause and s.get("state") == "paused":
                    continue
                mapping = Mapping.query.filter_by(titre_plex=s["titre_plex"]).first()
                if not mapping or mapping.library_id_plex not in active_library_ids:
                    continue
                season_mapping = None
                if s.get("series_rating_key") and s.get("season"):
                    season_mapping = SeasonMapping.query.filter_by(
                        plex_rating_key=s["series_rating_key"],
                        plex_season_index=s["season"],
                    ).first()

                # Depuis le mapping saisonnier, aucune liaison au niveau de la série
                # n'est utilisée pour synchroniser AniList.
                if mapping and mapping.statut == "ignore":
                    continue
                if not season_mapping or season_mapping.statut == "ignore":
                    _log_error_throttled(
                        s["titre_plex"], s.get("episode"),
                        "Aucun mapping AniList pour cette saison",
                    )
                    continue

                # La seule conversion est le décalage positif ou négatif de la saison.
                plex_episode = s.get("episode")
                if plex_episode is None:
                    _log_error_throttled(
                        s["titre_plex"], None,
                        "Épisode Plex invalide : impossible de résoudre la cible AniList",
                    )
                    continue

                target = episode_resolver.resolve_episode(
                    plex_episode=plex_episode,
                    plex_season_index=s.get("season"),
                    season_mapping=season_mapping,
                )
                if not target:
                    _log_error_throttled(
                        s["titre_plex"], plex_episode,
                        "Impossible de résoudre l'épisode Plex vers AniList",
                    )
                    continue

                target_id = target.anilist_id
                episode = target.anilist_episode

                # Une saison peut maintenant cibler plusieurs comptes AniList.
                # Chaque compte possède son propre curseur de synchronisation.
                targets = SeasonSyncTarget.query.filter_by(season_mapping_id=season_mapping.id).all()
                if not targets:
                    # Compatibilité avec les anciennes bases : le token global reste utilisable.
                    legacy_token = Setting.get("anilist_token", "")
                    if legacy_token:
                        try:
                            update_progress(target_id, episode, legacy_token, mark_completed=auto_complete)
                            season_mapping.dernier_episode_sync = episode
                            season_mapping.dernier_anilist_id_sync = target_id
                            db.session.add(SyncHistory(
                                titre=s["titre_plex"], episode=episode, statut="succes",
                                message=f"Progression mise à jour sur AniList (id={target_id})",
                            ))
                        except AniListError as e:
                            _log_error_throttled(s["titre_plex"], episode, str(e))
                    db.session.commit()
                    continue

                changed = False
                for sync_target in targets:
                    account = sync_target.account
                    if not account or not account.actif or not account.token:
                        continue
                    if (episode is not None and
                        sync_target.dernier_episode_sync == episode and
                        sync_target.dernier_anilist_id_sync == target_id):
                        continue
                    try:
                        update_progress(target_id, episode, account.token, mark_completed=auto_complete)
                        sync_target.dernier_episode_sync = episode
                        sync_target.dernier_anilist_id_sync = target_id
                        changed = True
                        db.session.add(SyncHistory(
                            titre=s["titre_plex"], episode=episode, statut="succes",
                            message=f"Progression mise à jour sur AniList — {account.nom} (id={target_id})",
                        ))
                    except AniListError as e:
                        _log_error_throttled(
                            s["titre_plex"], episode,
                            f"{account.nom}: {e}"
                        )
                if changed:
                    season_mapping.dernier_episode_sync = episode
                    season_mapping.dernier_anilist_id_sync = target_id
                db.session.commit()

    # --- API publique : relancer une sync pour un titre donné ---
    def retry(self, titre_plex, episode=None):
        """Relance conservée pour compatibilité, mais uniquement via un mapping de saison.

        L'historique actuel ne mémorise pas encore le numéro de saison ; on évite donc
        volontairement de retomber sur un ancien mapping de série.
        """
        with self.app.app_context():
            return False, "La relance nécessite un mapping de saison explicite"



# Instance globale (créée dans app.py)
worker = None

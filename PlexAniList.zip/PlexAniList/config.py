"""
Configuration globale de l'application PlexAniList Dashboard.

Les valeurs par défaut sont pré-remplies pour faciliter le premier démarrage.
Elles peuvent être modifiées via la page Paramètres (puis écrites en BDD SQLite).
"""

import os
import secrets

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
_SECRET_KEY_FILE = os.path.join(BASE_DIR, ".secret_key")


def _load_or_create_secret_key():
    """Ne jamais coder en dur une clé secrète : on en génère une aléatoire au
    premier lancement et on la persiste localement (hors du dépôt de code)."""
    env_key = os.environ.get("PlexAniList_SECRET")
    if env_key:
        return env_key
    if os.path.exists(_SECRET_KEY_FILE):
        with open(_SECRET_KEY_FILE, "r", encoding="utf-8") as f:
            key = f.read().strip()
            if key:
                return key
    key = secrets.token_hex(32)
    with open(_SECRET_KEY_FILE, "w", encoding="utf-8") as f:
        f.write(key)
    return key


class Config:
    # --- Clé interne Flask ---
    # Conservée pour les composants Flask qui peuvent en avoir besoin, mais
    # l'application n'utilise plus de page de connexion ni de mot de passe.
    SECRET_KEY = _load_or_create_secret_key()

    # --- Base de données ---
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(BASE_DIR, "PlexAniList.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # --- Valeurs par défaut Plex / AniList ---
    # Volontairement vides : on ne code plus de token/URL réels en dur dans le
    # code source (risque de fuite si le projet est partagé/versionné).
    # Configurez-les depuis la page Paramètres au premier lancement.
    DEFAULT_PLEX_URL = os.environ.get("PlexAniList_PLEX_URL", "http://127.0.0.1:32400")
    DEFAULT_PLEX_TOKEN = os.environ.get("PlexAniList_PLEX_TOKEN", "")
    DEFAULT_ANILIST_TOKEN = os.environ.get("PlexAniList_ANILIST_TOKEN", "")

    # --- Comportement du worker ---
    DEFAULT_PROGRESS_THRESHOLD = 85        # % au-dessus duquel on synchronise
    DEFAULT_POLL_INTERVAL = 30             # secondes entre deux vérifications
    DEFAULT_SYNC_ON_PAUSE = True           # sync même si la lecture est en pause au-dessus du seuil
    DEFAULT_AUTO_COMPLETE = True           # passer l'entrée AniList en "Terminé" au dernier épisode

    # --- Serveur Flask ---
    HOST = "127.0.0.1"
    PORT = 6060

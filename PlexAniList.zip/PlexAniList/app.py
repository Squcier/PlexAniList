"""
PlexAniList Dashboard — application Flask.

Point d'entrée principal. Définit :
- la création de l'app Flask et de la base SQLite au démarrage ;
- les routes HTML (dashboard, libraries, history, mapping, settings) ;
- les routes JSON /api/* consommées par le JavaScript des pages ;
- le démarrage du worker en thread de fond.

Lancement : `python app.py`
"""

import io
import json
import os
import re
from datetime import datetime, timedelta
from urllib.parse import quote

from flask import (
    Flask, render_template, request, redirect, url_for,
    jsonify, abort, send_file,
)

from config import Config
from models import db, Library, Mapping, SeasonMapping, MappingRule, SyncHistory, Setting, AniListAccount, SeasonSyncTarget
import plex_client
import anilist_client
import idmapper_client
import episode_resolver
from sync_worker import SyncWorker, worker
from mapping_scanner import MappingScanner, MappingAutomation


# ----------------- Application factory -----------------
def create_app():
    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.config.from_object(Config)
    db.init_app(app)

    from sqlalchemy import event
    from sqlalchemy.engine import Engine

    @event.listens_for(Engine, "connect")
    def configure_sqlite(connection, record):
        import sqlite3
        if not isinstance(connection, sqlite3.Connection):
            return
        cursor = connection.cursor()
        cursor.execute("PRAGMA busy_timeout=5000")
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.close()

    with app.app_context():
        db.create_all()
        _migrate_schema()
        _seed_default_settings()
        _seed_anilist_accounts()

    return app


def _migrate_schema():
    """Ajoute les colonnes manquantes sur une base SQLite déjà créée par une
    version antérieure de l'app (db.create_all() ne modifie jamais les tables
    existantes)."""
    from sqlalchemy import inspect, text

    insp = inspect(db.engine)

    mapping_cols = {c["name"] for c in insp.get_columns("mappings")}
    to_add_mapping = []
    if "plex_rating_key" not in mapping_cols:
        to_add_mapping.append(("plex_rating_key", "VARCHAR(64)"))
    if "plex_thumb" not in mapping_cols:
        to_add_mapping.append(("plex_thumb", "VARCHAR(512)"))
    if "plex_year" not in mapping_cols:
        to_add_mapping.append(("plex_year", "INTEGER"))
    if "library_id_plex" not in mapping_cols:
        to_add_mapping.append(("library_id_plex", "VARCHAR(64)"))
    if "dernier_episode_sync" not in mapping_cols:
        to_add_mapping.append(("dernier_episode_sync", "INTEGER"))
    if "tvdb_id" not in mapping_cols:
        to_add_mapping.append(("tvdb_id", "INTEGER"))
    for name, coltype in to_add_mapping:
        db.session.execute(text(f"ALTER TABLE mappings ADD COLUMN {name} {coltype}"))

    season_cols = {c["name"] for c in insp.get_columns("season_mappings")}
    to_add_season = []
    if "anilist_episode_offset" not in season_cols:
        to_add_season.append(("anilist_episode_offset", "INTEGER"))
    if "dernier_anilist_id_sync" not in season_cols:
        to_add_season.append(("dernier_anilist_id_sync", "INTEGER"))
    if "conversion_plan" not in season_cols:
        to_add_season.append(("conversion_plan", "TEXT"))
    if "conversion_confidence" not in season_cols:
        to_add_season.append(("conversion_confidence", "VARCHAR(20)"))
    if "conversion_reason" not in season_cols:
        to_add_season.append(("conversion_reason", "VARCHAR(500)"))
    for name, coltype in to_add_season:
        db.session.execute(text(f"ALTER TABLE season_mappings ADD COLUMN {name} {coltype}"))

    library_cols = {c["name"] for c in insp.get_columns("libraries")}
    library_type_missing = "type" not in library_cols
    if library_type_missing:
        db.session.execute(text("ALTER TABLE libraries ADD COLUMN type VARCHAR(32)"))

    if to_add_mapping or to_add_season or library_type_missing:
        db.session.commit()

    # Migration additive et répétable pour les bases existantes.
    db.session.execute(text(
        "CREATE INDEX IF NOT EXISTS ix_sync_history_titre_statut_date "
        "ON sync_history (titre, statut, date)"
    ))
    db.session.commit()

    # Nettoie les plans hérités : seul le décalage manuel est utilisé.
    SeasonMapping.query.filter(SeasonMapping.conversion_plan.isnot(None)).update(
        {"conversion_plan": None, "conversion_confidence": None, "conversion_reason": None},
        synchronize_session=False,
    )
    db.session.commit()


def _seed_default_settings():
    """Insère les valeurs par défaut si la table settings est vide."""
    defaults = {
        "plex_url": Config.DEFAULT_PLEX_URL,
        "plex_token": Config.DEFAULT_PLEX_TOKEN,
        "anilist_token": Config.DEFAULT_ANILIST_TOKEN,
        "progress_threshold": str(Config.DEFAULT_PROGRESS_THRESHOLD),
        "poll_interval": str(Config.DEFAULT_POLL_INTERVAL),
        "sync_on_pause": "1" if Config.DEFAULT_SYNC_ON_PAUSE else "0",
        "auto_complete": "1" if Config.DEFAULT_AUTO_COMPLETE else "0",
        "auto_scan_enabled": "0",
        "auto_scan_interval_hours": "6",
        "auto_link_enabled": "0",
        "auto_link_interval_hours": "6",
    }
    for k, v in defaults.items():
        if Setting.get(k) is None:
            Setting.set(k, v)


def _seed_anilist_accounts():
    """Convertit l'ancien token global en compte nommé lors de la première mise à niveau."""
    if AniListAccount.query.count() == 0:
        token = Setting.get("anilist_token", "") or ""
        if token:
            account = AniListAccount(nom="Compte principal", token=token, actif=True)
            db.session.add(account)
            db.session.flush()
            for sm in SeasonMapping.query.filter(SeasonMapping.anilist_id.isnot(None)).all():
                db.session.add(SeasonSyncTarget(season_mapping_id=sm.id, anilist_account_id=account.id))
            db.session.commit()

def _default_anilist_token():
    account = AniListAccount.query.filter_by(actif=True).order_by(AniListAccount.id).first()
    return (account.token if account else None) or Setting.get("anilist_token", "") or None

# ----------------- Worker -----------------
worker = SyncWorker  # référence (l'instance réelle est créée plus bas)


def start_worker(app):
    w = SyncWorker(app)
    w.start()
    return w


# ----------------- Routes HTML -----------------
app = create_app()
worker_instance = start_worker(app)
scanner_instance = MappingScanner(app)
automation_instance = MappingAutomation(app, scanner_instance)
automation_instance.start()


def _plex_link(plex_url, machine_id, rating_key):
    if not machine_id or not rating_key or not plex_url:
        return None
    key = f"/library/metadata/{rating_key}"
    return f"{plex_url.rstrip('/')}/web/index.html#!/server/{machine_id}/details?key={quote(key, safe='')}"


def _plex_thumb_url(plex_url, plex_token, thumb_path):
    if not thumb_path or not plex_url:
        return None
    return f"{plex_url.rstrip('/')}{thumb_path}?X-Plex-Token={plex_token}"


def _enrich_mapping(m_dict):
    """Ajoute les liens de vérification (Plex / AniList) et l'URL de la miniature."""
    plex_url = Setting.get("plex_url", "")
    plex_token = Setting.get("plex_token", "")
    machine_id = Setting.get("plex_machine_id", "")
    m_dict["plex_link"] = _plex_link(plex_url, machine_id, m_dict.get("plex_rating_key"))
    m_dict["plex_thumb_url"] = _plex_thumb_url(plex_url, plex_token, m_dict.get("plex_thumb"))
    m_dict["anilist_link"] = (
        f"https://anilist.co/anime/{m_dict['anilist_id']}" if m_dict.get("anilist_id") else None
    )
    return m_dict


@app.route("/")
def index():
    return redirect(url_for("mapping"))


@app.route("/libraries")
def libraries():
    return render_template("libraries.html")


@app.route("/mapping")
def mapping():
    return render_template("mapping.html")


@app.route("/settings")
def settings_page():
    return render_template("settings.html")


# ----------------- API JSON -----------------
@app.route("/api/stats")
def api_stats():
    today = datetime.utcnow().date()
    week_start = today - timedelta(days=6)

    rows_today = SyncHistory.query.filter(
        SyncHistory.statut == "succes",
        db.func.date(SyncHistory.date) == today,
    ).count()
    rows_week = SyncHistory.query.filter(
        SyncHistory.statut == "succes",
        db.func.date(SyncHistory.date) >= week_start,
    ).count()
    rows_total = SyncHistory.query.filter(SyncHistory.statut == "succes").count()
    rows_errors = SyncHistory.query.filter(SyncHistory.statut == "erreur").count()

    # Activité 7 derniers jours
    activity = []
    for i in range(6, -1, -1):
        d = today - timedelta(days=i)
        c = SyncHistory.query.filter(
            SyncHistory.statut == "succes",
            db.func.date(SyncHistory.date) == d,
        ).count()
        activity.append({"date": d.strftime("%Y-%m-%d"), "count": c})

    return jsonify({
        "today": rows_today,
        "week": rows_week,
        "total": rows_total,
        "errors": rows_errors,
        "activity": activity,
        "worker": worker_instance.status(),
    })


@app.route("/api/worker/toggle", methods=["POST"])
def api_worker_toggle():
    if worker_instance.is_paused():
        worker_instance.resume()
    else:
        worker_instance.pause()
    return jsonify(worker_instance.status())


@app.route("/api/libraries")
def api_libraries():
    """Renvoie les bibliothèques telles que connues en BDD (avec fallback distant)."""
    saved = {l.id_plex: l for l in Library.query.all()}

    plex_url = Setting.get("plex_url", Config.DEFAULT_PLEX_URL)
    plex_token = Setting.get("plex_token", "")
    remote = []
    err = None
    if plex_token:
        try:
            remote = plex_client.list_libraries(plex_url, plex_token)
        except plex_client.PlexError as e:
            err = str(e)

    # Si on a pu joindre Plex, on synchronise la table (sans écraser activee)
    if remote:
        for r in remote:
            existing = saved.get(r["id_plex"])
            if not existing:
                db.session.add(Library(
                    id_plex=r["id_plex"],
                    nom=r["nom"],
                    activee=True,
                    type=r.get("type"),
                ))
            else:
                existing.nom = r["nom"]
                existing.type = r.get("type")
        db.session.commit()
        saved = {l.id_plex: l for l in Library.query.all()}

    out = []
    for r in (remote or [{"id_plex": l.id_plex, "nom": l.nom, "type": l.type} for l in saved.values()]):
        l = saved.get(r["id_plex"])
        out.append({
            "id_plex": r["id_plex"],
            "nom": r["nom"],
            "type": r.get("type"),
            "activee": l.activee if l else True,
        })
    return jsonify({"libraries": out, "error": err})


@app.route("/api/libraries/toggle", methods=["POST"])
def api_libraries_toggle():
    data = request.get_json() or {}
    id_plex = str(data.get("id_plex"))
    activee = bool(data.get("activee"))
    lib = Library.query.filter_by(id_plex=id_plex).first()
    if not lib:
        return jsonify({"ok": False, "error": "Bibliothèque inconnue"}), 404
    lib.activee = activee
    db.session.commit()
    return jsonify({"ok": True})


@app.route("/api/history")
def api_history():
    statut = request.args.get("statut")
    search = request.args.get("q", "").strip()
    q = SyncHistory.query.order_by(SyncHistory.date.desc())
    if statut:
        q = q.filter_by(statut=statut)
    if search:
        q = q.filter(SyncHistory.titre.ilike(f"%{search}%"))
    return jsonify({"rows": [r.to_dict() for r in q.limit(500).all()]})


@app.route("/api/history/retry", methods=["POST"])
def api_history_retry():
    data = request.get_json() or {}
    hid = data.get("id")
    row = SyncHistory.query.get(hid)
    if not row:
        return jsonify({"ok": False, "error": "Entrée introuvable"}), 404
    ok, msg = worker_instance.retry(row.titre, row.episode)
    return jsonify({"ok": ok, "message": msg})


@app.route("/api/mapping")
def api_mapping():
    rows = Mapping.query.order_by(Mapping.titre_plex).all()
    library_names = {l.id_plex: l.nom for l in Library.query.all()}
    out = []
    for row in rows:
        item = _enrich_mapping(row.to_dict())
        item["library_name"] = library_names.get(row.library_id_plex, row.library_id_plex or "")
        # Le statut affiché au niveau série est uniquement un résumé des saisons.
        # Il ne constitue jamais un mapping AniList de série.
        seasons = SeasonMapping.query.filter_by(plex_rating_key=row.plex_rating_key).all() if row.plex_rating_key else []
        linked = [s for s in seasons if s.anilist_id]
        item["season_count"] = len(seasons)
        item["season_linked_count"] = len(linked)
        # Les comptes de synchronisation sont désormais gérés au niveau de la série
        # dans l'interface. En interne, ils restent stockés sur chaque saison pour
        # conserver un curseur indépendant par compte et par saison.
        account_map = {}
        for sm in seasons:
            for target in SeasonSyncTarget.query.filter_by(season_mapping_id=sm.id).join(AniListAccount).all():
                if target.account and target.account.actif:
                    account_map[target.account.id] = target.account.nom
        item["sync_accounts"] = [
            {"id": aid, "nom": name}
            for aid, name in sorted(account_map.items(), key=lambda x: x[0])
        ]
        item["sync_account_ids"] = sorted(account_map.keys())
        if not seasons or len(linked) < len(seasons):
            item["statut"] = "non_lie"
        elif any(s.statut == "a_verifier" for s in seasons):
            item["statut"] = "a_verifier"
        elif any(s.statut == "manuel" for s in seasons):
            item["statut"] = "manuel"
        elif all(s.statut == "ignore" for s in seasons):
            item["statut"] = "ignore"
        else:
            item["statut"] = "auto"
        item["anilist_id"] = None
        item["titre_anilist"] = None
        item["image_anilist"] = None
        item["anilist_link"] = None
        out.append(item)
    return jsonify({"rows": out})


@app.route("/api/mapping/seasons")
def api_mapping_seasons():
    rating_key = (request.args.get("plex_rating_key") or "").strip()
    if not rating_key:
        return jsonify({"rows": []})
    plex_url = Setting.get("plex_url", "")
    plex_token = Setting.get("plex_token", "")
    parent = Mapping.query.filter_by(plex_rating_key=rating_key).first()
    title = parent.titre_plex if parent else ""
    try:
        seasons = plex_client.list_seasons(plex_url, plex_token, rating_key)
    except plex_client.PlexError as e:
        return jsonify({"rows": [], "error": str(e)}), 502

    out = []
    for season in seasons:
        sm = SeasonMapping.query.filter_by(
            plex_rating_key=rating_key, plex_season_index=season["season_index"]
        ).first()
        if not sm:
            sm = SeasonMapping(
                plex_rating_key=rating_key,
                plex_season_index=season["season_index"],
                plex_season_rating_key=season.get("rating_key"),
                titre_plex=title,
                titre_saison=season.get("titre"),
                statut="non_lie",
            )
            db.session.add(sm)
            db.session.flush()
            # Le compte principal (premier compte actif) reste la cible par défaut.
            # Les comptes supplémentaires sont ajoutés explicitement au niveau de la série.
            default_account = AniListAccount.query.filter_by(actif=True).order_by(AniListAccount.id).first()
            if default_account:
                db.session.add(SeasonSyncTarget(season_mapping_id=sm.id, anilist_account_id=default_account.id))
        else:
            sm.plex_season_rating_key = season.get("rating_key")
            sm.titre_plex = title
            sm.titre_saison = season.get("titre")
        item = sm.to_dict()
        item["sync_accounts"] = [
            {"id": t.account.id, "nom": t.account.nom, "actif": bool(t.account.actif)}
            for t in SeasonSyncTarget.query.filter_by(season_mapping_id=sm.id).join(AniListAccount).order_by(AniListAccount.id).all()
        ]
        item.update({
            "plex_thumb": season.get("thumb"),
            "episodes": season.get("episodes", 0),
            "series_title": title,
            "tvdb_id": parent.tvdb_id if parent else None,
        })
        if parent and parent.tvdb_id:
            item["tvdb_series_link"] = f"https://www.thetvdb.com/series/{parent.tvdb_id}"
            tvdb_season = int(season.get("season_index") or 0)
            if tvdb_season > 0:
                item["tvdb_season_link"] = f"https://www.thetvdb.com/series/{parent.tvdb_id}/seasons/official/{tvdb_season}"
        item = _enrich_mapping(item)
        try:
            item["season_offset"] = int(sm.anilist_episode_offset) if sm.anilist_episode_offset is not None else None
        except (TypeError, ValueError):
            item["season_offset"] = None
        # Pour une saison, le lien Plex pointe directement sur la saison et
        # non sur la série parente.
        if item.get("plex_season_rating_key"):
            item["plex_link"] = _plex_link(
                Setting.get("plex_url", ""),
                Setting.get("plex_machine_id", ""),
                item.get("plex_season_rating_key"),
            )
        out.append(item)
    db.session.commit()
    return jsonify({"rows": out})


@app.route("/api/mapping/resolve")
def api_mapping_resolve():
    rating_key = str(request.args.get("plex_rating_key") or "").strip()
    try:
        season_index = int(request.args.get("season_index") or 0)
        episode = int(request.args.get("episode") or 0)
    except (TypeError, ValueError):
        season_index = episode = 0
    if not rating_key or season_index <= 0 or episode <= 0:
        return jsonify({"ok": False, "error": "Saison ou épisode invalide"}), 400
    sm = SeasonMapping.query.filter_by(plex_rating_key=rating_key, plex_season_index=season_index).first()
    if not sm:
        return jsonify({"ok": False, "error": "Mapping de saison introuvable"}), 404
    target = episode_resolver.resolve_episode(
        plex_episode=episode, plex_season_index=season_index, season_mapping=sm
    )
    if not target:
        return jsonify({"ok": True, "matched": False, "message": "Le décalage produit un numéro AniList inférieur à 1."})
    return jsonify({"ok": True, "matched": True, "result": target.to_dict()})


@app.route("/api/mapping/conversion")
def api_mapping_conversion():
    """Retourne uniquement l'aperçu du décalage de la saison."""
    rating_key = str(request.args.get("plex_rating_key") or "").strip()
    try:
        season_index = int(request.args.get("season_index") or 0)
    except (TypeError, ValueError):
        season_index = 0
    if not rating_key or season_index <= 0:
        return jsonify({"ok": False, "error": "Saison invalide"}), 400

    sm = SeasonMapping.query.filter_by(plex_rating_key=rating_key, plex_season_index=season_index).first()
    parent = Mapping.query.filter_by(plex_rating_key=rating_key).first()
    if not sm or not parent:
        return jsonify({"ok": False, "error": "Saison introuvable"}), 404

    try:
        seasons = plex_client.list_seasons(Setting.get("plex_url", ""), Setting.get("plex_token", ""), rating_key)
        season = next((x for x in seasons if int(x.get("season_index") or 0) == season_index), None)
    except Exception:
        season = None
    count = int((season or {}).get("episodes") or 0)

    try:
        offset = int(sm.anilist_episode_offset or 0)
    except (TypeError, ValueError):
        offset = 0

    rows = []
    for ep in range(1, count + 1):
        target = ep + offset
        rows.append({
            "plex_episode": ep,
            "anilist_id": int(sm.anilist_id) if sm.anilist_id and target > 0 else None,
            "anilist_episode": target if target > 0 else None,
            "valid": target > 0,
        })

    return jsonify({
        "ok": True,
        "season": {"index": season_index, "title": sm.titre_saison, "episodes": count},
        "season_offset": offset if sm.anilist_episode_offset is not None else None,
        "anilist_id": sm.anilist_id,
        "rows": rows,
    })


@app.route("/api/mapping/season-offset", methods=["GET"])
def api_mapping_season_offset_get():
    rating_key = str(request.args.get("plex_rating_key") or "").strip()
    season_index = int(request.args.get("season_index") or 0)
    if not rating_key or season_index <= 0:
        return jsonify({"ok": False, "error": "Saison invalide"}), 400
    sm = SeasonMapping.query.filter_by(plex_rating_key=rating_key, plex_season_index=season_index).first()
    if not sm:
        return jsonify({"ok": False, "error": "Saison introuvable"}), 404
    return jsonify({"ok": True, "offset": sm.anilist_episode_offset})


@app.route("/api/mapping/season-offset", methods=["POST"])
def api_mapping_season_offset_save():
    data = request.get_json() or {}
    rating_key = str(data.get("plex_rating_key") or "").strip()
    try:
        season_index = int(data.get("season_index") or 0)
        offset = int(data.get("offset"))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "Le décalage doit être un entier, positif, nul ou négatif."}), 400
    if not rating_key or season_index <= 0:
        return jsonify({"ok": False, "error": "Saison invalide"}), 400
    sm = SeasonMapping.query.filter_by(plex_rating_key=rating_key, plex_season_index=season_index).first()
    if not sm:
        return jsonify({"ok": False, "error": "Saison introuvable"}), 404
    # Un offset négatif est autorisé. Les épisodes qui tomberaient avant E1
    # seront simplement signalés comme non résolus dans l'aperçu.
    sm.anilist_episode_offset = offset
    db.session.commit()
    return jsonify({"ok": True, "offset": offset, "mapping": sm.to_dict()})


@app.route("/api/mapping/season-offset", methods=["DELETE"])
def api_mapping_season_offset_delete():
    data = request.get_json(silent=True) or {}
    rating_key = str(data.get("plex_rating_key") or request.args.get("plex_rating_key") or "").strip()
    season_index = int(data.get("season_index") or request.args.get("season_index") or 0)
    if not rating_key or season_index <= 0:
        return jsonify({"ok": False, "error": "Saison invalide"}), 400
    sm = SeasonMapping.query.filter_by(plex_rating_key=rating_key, plex_season_index=season_index).first()
    if not sm:
        return jsonify({"ok": False, "error": "Saison introuvable"}), 404
    sm.anilist_episode_offset = None
    db.session.commit()
    return jsonify({"ok": True})


def _tvdb_bridge(parent):
    if not parent or not parent.tvdb_id:
        return None
    try:
        return idmapper_client.lookup_tvdb(parent.tvdb_id)
    except Exception:
        return None


def _season_conversion(parent, sm, episode_count=None):
    """Aperçu interne : la seule conversion est Plex E + offset."""
    rows = []
    count = int(episode_count or 0)
    try:
        offset = int(sm.anilist_episode_offset or 0)
    except (TypeError, ValueError):
        offset = 0
    for ep in range(1, count + 1):
        target = ep + offset
        rows.append({
            "plex_episode": ep,
            "anilist_id": sm.anilist_id if sm.anilist_id and target > 0 else None,
            "anilist_episode": target if target > 0 else None,
            "source": "season_offset" if offset else "season_direct",
        })
    return rows


def _season_resolution_preview(parent, sm, episode=1, episode_count=None):
    rows = _season_conversion(parent, sm, episode_count or max(episode, 1))
    target = next((x for x in rows if x.get("plex_episode") == episode), None)
    if not target:
        return None
    try:
        offset = int(sm.anilist_episode_offset or 0)
    except (TypeError, ValueError):
        offset = 0
    return {
        "offset": offset if sm.anilist_episode_offset is not None else None,
        "example": f"E{episode} → E{target['anilist_episode']}" if target.get("anilist_episode") else f"E{episode} → non résolu",
    }


@app.route("/api/mapping/season-auto-match", methods=["POST"])
def api_mapping_season_auto_match():
    data = request.get_json() or {}
    rating_key = str(data.get("plex_rating_key") or "").strip()
    season_index = int(data.get("season_index") or 0)
    if not rating_key or season_index <= 0:
        return jsonify({"ok": False, "error": "Paramètres manquants"}), 400
    sm = SeasonMapping.query.filter_by(plex_rating_key=rating_key, plex_season_index=season_index).first()
    parent = Mapping.query.filter_by(plex_rating_key=rating_key).first()
    if not sm:
        return jsonify({"ok": False, "error": "Saison introuvable"}), 404
    token = _default_anilist_token()
    series_title = parent.titre_plex if parent else sm.titre_plex
    try:
        candidates = anilist_client.search_season_media(series_title, season_index, sm.titre_saison, token=token)
        best, score, reason = _rank_season_candidates(candidates, series_title, season_index, sm.titre_saison)
        if not best:
            sm.statut = "introuvable"
            db.session.commit()
            return jsonify({"ok": True, "matched": False, "mapping": sm.to_dict()})

        sm.anilist_id = int(best["id"])
        sm.titre_anilist = best.get("title") or best.get("title_romaji") or best.get("title_english")
        sm.image_anilist = best.get("image")
        sm.statut = "auto" if score >= 75 else "a_verifier"

        plex_count = int(data.get("episode_count") or 0)

        db.session.commit()
        preview = _season_resolution_preview(parent, sm, 1, plex_count)
        return jsonify({
            "ok": True, "matched": True, "score": score, "reason": reason,
            "mapping": sm.to_dict(), "preview": preview,
        })
    except anilist_client.AniListError as e:
        return jsonify({"ok": False, "error": str(e)}), 502

def _season_names(item):
    vals = [item.get("title"), item.get("title_romaji"), item.get("title_english"), item.get("title_native")]
    vals += list(item.get("synonyms") or [])
    return [str(v) for v in vals if v]

def _norm_title(value):
    import re
    import unicodedata
    text = unicodedata.normalize("NFKD", (value or "").lower())
    text = "".join(c for c in text if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9]+", " ", text).strip()

def _rank_season_candidates(candidates, series_title, season_index, season_title=None):
    target_series = _norm_title(series_title)
    target_season = _norm_title(season_title or "")
    ranked = []
    for item in candidates:
        names = _season_names(item)
        norms = [_norm_title(x) for x in names]
        score = 0
        reasons = []
        # Saison 1 : l'absence de « Saison 1 » est normale, donc l'identité
        # exacte du titre de la série vaut davantage qu'un numéro absent.
        if target_series and any(n == target_series for n in norms):
            score += 88 if season_index == 1 else 55
            reasons.append("titre de série exact")
        elif target_series and any(target_series in n or n in target_series for n in norms):
            score += 68
            reasons.append("titre de série proche")
        if target_season and target_season in norms:
            score += 18
            reasons.append("titre de saison")
        text = " ".join(norms)
        number_tokens = {str(season_index), f"season {season_index}", f"saison {season_index}", f"part {season_index}"}
        if any(token in text for token in number_tokens):
            score += 20
            reasons.append(f"indice {season_index}")
        rel_types = {str(item.get("relation_type") or "").upper()}
        if "SEQUEL" in rel_types and season_index > 1:
            score += 15
            reasons.append("suite AniList")
        if "PREQUEL" in rel_types and season_index > 1:
            score -= 12
        # Un résultat de relation sans title anglais/romaji peut tout de même
        # être utile, mais ne doit jamais battre un titre exact.
        ranked.append((score, item, ", ".join(reasons)))
    ranked.sort(key=lambda x: (x[0], -(int(x[1].get("id") or 0))), reverse=True)
    return (ranked[0][1], ranked[0][0], ranked[0][2]) if ranked else (None, 0, "")


@app.route("/api/mapping/season-auto-match-series", methods=["POST"])
def api_mapping_season_auto_match_series():
    """Lance la recherche pour toutes les saisons d'une série, jamais pour la série elle-même."""
    data = request.get_json() or {}
    rating_key = str(data.get("plex_rating_key") or "").strip()
    if not rating_key:
        return jsonify({"ok": False, "error": "plex_rating_key manquant"}), 400
    parent = Mapping.query.filter_by(plex_rating_key=rating_key).first()
    if not parent:
        return jsonify({"ok": False, "error": "Série introuvable"}), 404
    plex_url = Setting.get("plex_url", "")
    plex_token = Setting.get("plex_token", "")
    try:
        seasons = plex_client.list_seasons(plex_url, plex_token, rating_key)
    except plex_client.PlexError as e:
        return jsonify({"ok": False, "error": str(e)}), 502
    token = _default_anilist_token()
    matched = 0
    checked = 0
    skipped_linked = 0
    for season in seasons:
        idx = int(season.get("season_index") or 0)
        if idx <= 0:
            continue
        sm = SeasonMapping.query.filter_by(plex_rating_key=rating_key, plex_season_index=idx).first()
        if not sm:
            sm = SeasonMapping(plex_rating_key=rating_key, plex_season_index=idx, titre_plex=parent.titre_plex, titre_saison=season.get("titre"), statut="non_lie")
            db.session.add(sm)
        sm.plex_season_rating_key = season.get("rating_key")
        sm.titre_plex = parent.titre_plex
        sm.titre_saison = season.get("titre")
        if sm.statut == "ignore":
            continue
        # Une saison déjà liée a déjà une cible AniList. Le mapping groupé
        # ne la recherche jamais à nouveau : seules les saisons sans cible
        # sont candidates à une nouvelle recherche automatique.
        if sm.anilist_id is not None:
            skipped_linked += 1
            continue
        checked += 1
        try:
            candidates = anilist_client.search_season_media(
                parent.titre_plex, idx, sm.titre_saison, token=token
            )
            best, score, reason = _rank_season_candidates(
                candidates, parent.titre_plex, idx, sm.titre_saison
            )

            bridge = _tvdb_bridge(parent)
            if bridge and bridge.get("anilist_id") and (not best or score < 75):
                bridge_id = int(bridge["anilist_id"])
                bridge_item = next(
                    (x for x in candidates if int(x.get("id") or 0) == bridge_id), None
                ) or anilist_client.get_media_by_id(bridge_id, token=token)
                if bridge_item:
                    best = bridge_item
                    score = max(score, 80)
            if best:
                sm.anilist_id = int(best["id"])
                sm.titre_anilist = best.get("title") or best.get("title_romaji") or best.get("title_english")
                sm.image_anilist = best.get("image")
                sm.statut = "auto" if score >= 75 else "a_verifier"
                matched += 1
            else:
                sm.statut = "introuvable"
        except anilist_client.AniListError:
            sm.statut = "a_verifier"
        db.session.commit()
    return jsonify({"ok": True, "checked": checked, "matched": matched, "skipped_linked": skipped_linked})

@app.route("/api/mapping/season-reassign", methods=["POST"])
def api_mapping_season_reassign():
    data = request.get_json() or {}
    rating_key = str(data.get("plex_rating_key") or "").strip()
    season_index = int(data.get("season_index") or 0)
    anilist_id = data.get("anilist_id")
    if not rating_key or season_index <= 0 or not anilist_id:
        return jsonify({"ok": False, "error": "Paramètres manquants"}), 400
    sm = SeasonMapping.query.filter_by(plex_rating_key=rating_key, plex_season_index=season_index).first()
    if not sm:
        return jsonify({"ok": False, "error": "Saison introuvable"}), 404
    sm.anilist_id = int(anilist_id)
    sm.titre_anilist = data.get("titre_anilist")
    sm.image_anilist = data.get("image_anilist")
    sm.statut = "manuel"
    db.session.commit()
    return jsonify({"ok": True, "mapping": sm.to_dict()})


def _assign_accounts_to_seasons(seasons, account_ids):
    ids = []
    for raw in account_ids or []:
        try:
            value = int(raw)
            if value not in ids:
                ids.append(value)
        except (TypeError, ValueError):
            continue
    # Le premier compte (ID le plus ancien) est le compte principal : il est
    # toujours une cible et ne peut pas être retiré via le mapping.
    primary = AniListAccount.query.order_by(AniListAccount.id).first()
    if primary:
        ids = [primary.id] + [aid for aid in ids if aid != primary.id]
    accounts = AniListAccount.query.filter(AniListAccount.id.in_(ids), AniListAccount.actif.is_(True)).all() if ids else []
    valid_ids = {a.id for a in accounts}
    for sm in seasons:
        SeasonSyncTarget.query.filter_by(season_mapping_id=sm.id).delete(synchronize_session=False)
        for aid in ids:
            if aid in valid_ids:
                db.session.add(SeasonSyncTarget(season_mapping_id=sm.id, anilist_account_id=aid))
    return len(accounts)


@app.route("/api/mapping/season-accounts", methods=["POST"])
def api_mapping_season_accounts():
    data = request.get_json() or {}
    rk = str(data.get("plex_rating_key") or "").strip()
    try:
        si = int(data.get("season_index") or 0)
    except (TypeError, ValueError):
        si = 0
    sm = SeasonMapping.query.filter_by(plex_rating_key=rk, plex_season_index=si).first()
    if not sm:
        return jsonify({"ok": False, "error": "Saison introuvable."}), 404
    _assign_accounts_to_seasons([sm], data.get("account_ids") or [])
    db.session.commit()
    return jsonify({"ok": True, "accounts": [
        {"id": t.account.id, "nom": t.account.nom, "actif": bool(t.account.actif)}
        for t in sm.sync_targets
    ]})


@app.route("/api/mapping/series-accounts", methods=["POST"])
def api_mapping_series_accounts():
    data = request.get_json() or {}
    keys = data.get("plex_rating_keys") or []
    if not isinstance(keys, list) or not keys:
        return jsonify({"ok": False, "error": "Aucune série sélectionnée."}), 400
    keys = [str(k).strip() for k in keys if str(k).strip()]
    seasons = SeasonMapping.query.filter(SeasonMapping.plex_rating_key.in_(keys)).all()
    count = _assign_accounts_to_seasons(seasons, data.get("account_ids") or [])
    db.session.commit()
    return jsonify({"ok": True, "series": len(set(s.plex_rating_key for s in seasons)), "seasons": len(seasons), "accounts": count})


@app.route("/api/mapping/scan", methods=["POST"])
def api_mapping_scan():
    started = scanner_instance.start()
    if not started:
        return jsonify({"ok": False, "error": "Un scan est déjà en cours"}), 409
    return jsonify({"ok": True, "status": scanner_instance.status()})


@app.route("/api/mapping/scan/status")
def api_mapping_scan_status():
    return jsonify(scanner_instance.status())


@app.route("/api/mapping/ignore", methods=["POST"])
def api_mapping_ignore():
    """Bascule un mapping entre 'ignore' et son état précédent (ré-active en 'introuvable'
    puis laisse le prochain scan retenter un match, sauf si l'utilisateur re-choisit manuellement)."""
    data = request.get_json() or {}
    titre_plex = (data.get("titre_plex") or "").strip()
    m = Mapping.query.filter_by(titre_plex=titre_plex).first()
    if not m:
        return jsonify({"ok": False, "error": "Mapping introuvable"}), 404
    if m.statut == "ignore":
        m.statut = "introuvable" if not m.anilist_id else "manuel"
    else:
        m.statut = "ignore"
    db.session.commit()
    return jsonify({"ok": True, "mapping": m.to_dict()})


@app.route("/api/mapping/delete", methods=["POST"])
def api_mapping_delete():
    data = request.get_json() or {}
    titre_plex = (data.get("titre_plex") or "").strip()
    m = Mapping.query.filter_by(titre_plex=titre_plex).first()
    if not m:
        return jsonify({"ok": False, "error": "Mapping introuvable"}), 404

    # Une série est désormais un conteneur : supprimer son mapping doit aussi
    # supprimer toutes ses liaisons de saisons, sinon elles restent orphelines
    # et réapparaissent dans l'interface au prochain chargement.
    for sm in SeasonMapping.query.filter_by(plex_rating_key=m.plex_rating_key).all():
        SeasonSyncTarget.query.filter_by(season_mapping_id=sm.id).delete(synchronize_session=False)
    SeasonMapping.query.filter_by(plex_rating_key=m.plex_rating_key).delete(synchronize_session=False)
    db.session.delete(m)
    db.session.commit()
    return jsonify({"ok": True})


@app.route("/api/mapping/delete-bulk", methods=["POST"])
def api_mapping_delete_bulk():
    data = request.get_json() or {}
    # Les nouvelles sélections utilisent la clé Plex, qui identifie une série
    # sans ambiguïté. Les titres restent acceptés pour compatibilité avec les
    # anciennes versions de l'interface.
    rating_keys = data.get("plex_rating_keys")
    titres = data.get("titres") or []

    if rating_keys is not None and not isinstance(rating_keys, list):
        return jsonify({"ok": False, "error": "Liste de clés Plex invalide"}), 400
    if not isinstance(titres, list):
        return jsonify({"ok": False, "error": "Liste de titres invalide"}), 400

    mappings = []
    if rating_keys:
        keys = [str(k).strip() for k in rating_keys if str(k).strip()]
        if keys:
            mappings = Mapping.query.filter(Mapping.plex_rating_key.in_(keys)).all()
    elif titres:
        mappings = Mapping.query.filter(Mapping.titre_plex.in_(titres)).all()

    deleted = 0
    for m in mappings:
        for sm in SeasonMapping.query.filter_by(plex_rating_key=m.plex_rating_key).all():
            SeasonSyncTarget.query.filter_by(season_mapping_id=sm.id).delete(synchronize_session=False)
        SeasonMapping.query.filter_by(plex_rating_key=m.plex_rating_key).delete(synchronize_session=False)
        db.session.delete(m)
        deleted += 1

    if mappings:
        db.session.commit()
    return jsonify({"ok": True, "deleted": deleted})


@app.route("/api/anilist/search-season")
def api_anilist_search_season():
    rating_key = str(request.args.get("plex_rating_key") or "").strip()
    season_index = int(request.args.get("season_index") or 0)
    q = request.args.get("q", "").strip()
    if not rating_key or season_index <= 0:
        return jsonify({"results": [], "error": "Saison invalide"}), 400
    sm = SeasonMapping.query.filter_by(plex_rating_key=rating_key, plex_season_index=season_index).first()
    parent = Mapping.query.filter_by(plex_rating_key=rating_key).first()
    if not sm or not parent:
        return jsonify({"results": [], "error": "Saison introuvable"}), 404
    token = _default_anilist_token()
    try:
        candidates = anilist_client.search_season_media(parent.titre_plex, season_index, sm.titre_saison, query=q or None, token=token)
        ranked=[]
        for item in candidates:
            best, score, reason = _rank_season_candidates([item], parent.titre_plex, season_index, sm.titre_saison)
            if best:
                ranked.append((score, reason, item))
        ranked.sort(key=lambda x: x[0], reverse=True)
        out=[]
        for score, reason, item in ranked[:24]:
            copy=dict(item)
            copy["match_reason"] = reason or ("Candidat AniList" if score else "")
            copy["match_score"] = score
            out.append(copy)
        return jsonify({"results": out, "season": season_index, "series_title": parent.titre_plex})
    except anilist_client.AniListError as e:
        return jsonify({"results": [], "error": str(e)}), 502

@app.route("/api/anilist/by-id")
def api_anilist_by_id():
    raw = (request.args.get("id") or "").strip()
    m = re.search(r"(?:anilist\.co/anime/)?(\d+)", raw, re.I)
    if not m:
        return jsonify({"ok": False, "error": "Entrez un ID AniList ou une URL anilist.co/anime/..."}), 400
    token = _default_anilist_token()
    try:
        item = anilist_client.get_media_by_id(int(m.group(1)), token=token)
        if not item:
            return jsonify({"ok": False, "error": "Anime AniList introuvable"}), 404
        return jsonify({"ok": True, "result": item})
    except anilist_client.AniListError as e:
        return jsonify({"ok": False, "error": str(e)}), 502


@app.route("/api/anilist/search")
def api_anilist_search():
    q = request.args.get("q", "").strip()
    if not q:
        return jsonify({"results": []})
    token = Setting.get("anilist_token", "")
    try:
        results = anilist_client.search_media(q, token=token or None)
        return jsonify({"results": results})
    except anilist_client.AniListError as e:
        return jsonify({"results": [], "error": str(e)}), 502


@app.route("/api/settings", methods=["GET", "POST"])
def api_settings():
    text_keys = [
        "plex_url", "plex_token", "anilist_token", "progress_threshold", "poll_interval",
        "auto_scan_interval_hours", "auto_link_interval_hours",
    ]
    bool_keys = ["sync_on_pause", "auto_complete", "auto_scan_enabled", "auto_link_enabled"]

    if request.method == "GET":
        out = {k: (Setting.get(k, "") or "") for k in text_keys}
        out.update({k: Setting.get(k, "1") == "1" for k in bool_keys})
        return jsonify(out)

    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"ok": False, "error": "Paramètres JSON invalides."}), 400
    validated = {}
    ranges = {
        "progress_threshold": (float, 0, 100),
        "poll_interval": (int, 5, 3600),
        "auto_scan_interval_hours": (int, 1, 8760),
        "auto_link_interval_hours": (int, 1, 8760),
    }
    for k, value in data.items():
        if k in ranges:
            cast, low, high = ranges[k]
            try:
                number = cast(value)
                if isinstance(value, bool) or not low <= number <= high:
                    raise ValueError()
            except (TypeError, ValueError, OverflowError):
                return jsonify({"ok": False, "error": f"Valeur invalide pour {k} ({low} à {high})."}), 400
            validated[k] = str(number)
        elif k == "plex_url":
            from urllib.parse import urlparse
            url = str(value).strip()
            parts = urlparse(url)
            if parts.scheme not in ("http", "https") or not parts.hostname:
                return jsonify({"ok": False, "error": "URL Plex invalide (http:// ou https://)."}), 400
            validated[k] = url
        elif k in ("plex_token", "anilist_token"):
            validated[k] = str(value)
        elif k in bool_keys:
            if not isinstance(value, bool):
                return jsonify({"ok": False, "error": f"Valeur booléenne invalide pour {k}."}), 400
            validated[k] = "1" if value else "0"
    for k, value in validated.items():
        Setting.set(k, value)

    return jsonify({"ok": True})


@app.route("/api/settings/test-plex", methods=["POST"])
def api_settings_test_plex():
    """Teste une URL/token Plex sans les enregistrer (permet de vérifier avant de sauvegarder)."""
    data = request.get_json() or {}
    plex_url = data.get("plex_url") or Setting.get("plex_url", "")
    plex_token = data.get("plex_token") or Setting.get("plex_token", "")
    try:
        libs = plex_client.list_libraries(plex_url, plex_token)
        return jsonify({"ok": True, "message": f"Connexion réussie — {len(libs)} bibliothèque(s) trouvée(s)."})
    except plex_client.PlexError as e:
        return jsonify({"ok": False, "error": str(e)}), 502


@app.route("/api/anilist/accounts", methods=["GET", "POST"])
def api_anilist_accounts():
    if request.method == "GET":
        return jsonify({"accounts": [a.to_dict() for a in AniListAccount.query.order_by(AniListAccount.id).all()]})
    data = request.get_json() or {}
    name = str(data.get("nom") or "").strip()
    token = str(data.get("token") or "").strip()
    if not name or not token:
        return jsonify({"ok": False, "error": "Nom et token AniList obligatoires."}), 400
    if AniListAccount.query.filter(db.func.lower(AniListAccount.nom) == name.lower()).first():
        return jsonify({"ok": False, "error": "Ce nom de compte existe déjà."}), 409
    account = AniListAccount(nom=name, token=token, actif=bool(data.get("actif", True)))
    db.session.add(account)
    db.session.commit()
    return jsonify({"ok": True, "account": account.to_dict()})


@app.route("/api/anilist/accounts/<int:account_id>", methods=["PUT", "DELETE"])
def api_anilist_account(account_id):
    account = AniListAccount.query.get(account_id)
    if not account:
        return jsonify({"ok": False, "error": "Compte AniList introuvable."}), 404
    primary = AniListAccount.query.order_by(AniListAccount.id).first()
    if request.method == "DELETE":
        if primary and account.id == primary.id:
            return jsonify({"ok": False, "error": "Le compte principal ne peut pas être supprimé."}), 400
        SeasonSyncTarget.query.filter_by(anilist_account_id=account.id).delete(synchronize_session=False)
        db.session.delete(account)
        db.session.commit()
        return jsonify({"ok": True})
    data = request.get_json() or {}
    if "nom" in data:
        name = str(data.get("nom") or "").strip()
        if not name:
            return jsonify({"ok": False, "error": "Le nom est obligatoire."}), 400
        other = AniListAccount.query.filter(db.func.lower(AniListAccount.nom) == name.lower(), AniListAccount.id != account.id).first()
        if other:
            return jsonify({"ok": False, "error": "Ce nom de compte existe déjà."}), 409
        account.nom = name
    if "token" in data and str(data.get("token") or "").strip():
        account.token = str(data["token"]).strip()
    if "actif" in data:
        if primary and account.id == primary.id and not bool(data["actif"]):
            return jsonify({"ok": False, "error": "Le compte principal doit rester actif."}), 400
        account.actif = bool(data["actif"])
    db.session.commit()
    return jsonify({"ok": True, "account": account.to_dict()})


@app.route("/api/anilist/accounts/<int:account_id>/test", methods=["POST"])
def api_anilist_account_test(account_id):
    account = AniListAccount.query.get(account_id)
    if not account:
        return jsonify({"ok": False, "error": "Compte AniList introuvable."}), 404
    try:
        anilist_client.search_media("one piece", token=account.token or None)
        return jsonify({"ok": True, "message": f"Connexion réussie pour « {account.nom} »."})
    except anilist_client.AniListError as e:
        return jsonify({"ok": False, "error": str(e)}), 502


@app.route("/api/settings/test-anilist", methods=["POST"])
def api_settings_test_anilist():
    """Teste un token AniList sans l'enregistrer, via une recherche anodine."""
    data = request.get_json() or {}
    token = data.get("anilist_token") or _default_anilist_token()
    try:
        anilist_client.search_media("one piece", token=token or None)
        msg = "Connexion réussie" + (" (authentifié)." if token else " (anonyme, aucun token fourni).")
        return jsonify({"ok": True, "message": msg})
    except anilist_client.AniListError as e:
        return jsonify({"ok": False, "error": str(e)}), 502


# ----------------- Sauvegarde / restauration -----------------
BACKUP_VERSION = 3


def _backup_payload():
    """Construit une sauvegarde complète et portable de l'application.

    Les tokens Plex/AniList font volontairement partie de la sauvegarde : le
    fichier est donc à conserver comme un fichier confidentiel.
    """
    return {
        "format": "PlexAniList-backup",
        "version": BACKUP_VERSION,
        "exported_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "settings": [
            {"cle": s.cle, "valeur": s.valeur}
            for s in Setting.query.order_by(Setting.cle).all()
        ],
        "anilist_accounts": [
            {"id": a.id, "nom": a.nom, "token": a.token, "actif": bool(a.actif),
             "created_at": a.created_at.isoformat() if a.created_at else None}
            for a in AniListAccount.query.order_by(AniListAccount.id).all()
        ],
        "season_sync_targets": [
            {"plex_rating_key": t.season.plex_rating_key, "plex_season_index": t.season.plex_season_index,
             "account_id": t.anilist_account_id, "account_name": t.account.nom,
             "dernier_episode_sync": t.dernier_episode_sync,
             "dernier_anilist_id_sync": t.dernier_anilist_id_sync}
            for t in SeasonSyncTarget.query.join(SeasonMapping).join(AniListAccount).order_by(SeasonSyncTarget.id).all()
        ],
        "libraries": [
            {
                "id_plex": l.id_plex,
                "nom": l.nom,
                "activee": bool(l.activee),
                "type": l.type,
            }
            for l in Library.query.order_by(Library.nom).all()
        ],
        "mappings": [
            {
                "titre_plex": m.titre_plex,
                "anilist_id": m.anilist_id,
                "titre_anilist": m.titre_anilist,
                "image_anilist": m.image_anilist,
                "statut": m.statut,
                "plex_rating_key": m.plex_rating_key,
                "plex_thumb": m.plex_thumb,
                "plex_year": m.plex_year,
                "tvdb_id": m.tvdb_id,
                "library_id_plex": m.library_id_plex,
                "dernier_episode_sync": m.dernier_episode_sync,
            }
            for m in Mapping.query.order_by(Mapping.titre_plex).all()
        ],
        "mapping_rules": [r.to_dict() for r in MappingRule.query.order_by(MappingRule.id).all()],
        "season_mappings": [
            {
                "plex_rating_key": s.plex_rating_key,
                "plex_season_index": s.plex_season_index,
                "plex_season_rating_key": s.plex_season_rating_key,
                "titre_plex": s.titre_plex,
                "titre_saison": s.titre_saison,
                "anilist_id": s.anilist_id,
                "titre_anilist": s.titre_anilist,
                "image_anilist": s.image_anilist,
                "statut": s.statut,
                "dernier_episode_sync": s.dernier_episode_sync,
                "dernier_anilist_id_sync": s.dernier_anilist_id_sync,
                "anilist_episode_offset": s.anilist_episode_offset,
            }
            for s in SeasonMapping.query.order_by(SeasonMapping.titre_plex, SeasonMapping.plex_season_index).all()
        ],
        "history": [
            {
                "date": h.date.isoformat() if h.date else None,
                "titre": h.titre,
                "episode": h.episode,
                "statut": h.statut,
                "message": h.message,
            }
            for h in SyncHistory.query.order_by(SyncHistory.date).all()
        ],
    }


@app.route("/api/backup/export")
def api_backup_export():
    payload = _backup_payload()
    raw = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
    filename = f"PlexAniList_backup_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
    return send_file(
        io.BytesIO(raw),
        mimetype="application/json; charset=utf-8",
        as_attachment=True,
        download_name=filename,
    )


@app.route("/api/backup/import", methods=["POST"])
def api_backup_import():
    if scanner_instance.status().get("running"):
        return jsonify({"ok": False, "error": "Un scan est en cours. Attendez sa fin avant de restaurer une sauvegarde."}), 409
    upload = request.files.get("file")
    if not upload or not upload.filename:
        return jsonify({"ok": False, "error": "Aucun fichier de sauvegarde sélectionné."}), 400

    try:
        raw = upload.read(10 * 1024 * 1024 + 1)
        if len(raw) > 10 * 1024 * 1024:
            return jsonify({"ok": False, "error": "Le fichier dépasse la taille maximale de 10 Mo."}), 413
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        return jsonify({"ok": False, "error": f"Fichier JSON invalide : {exc}"}), 400

    if not isinstance(payload, dict) or payload.get("format") != "PlexAniList-backup":
        return jsonify({"ok": False, "error": "Ce fichier n'est pas une sauvegarde PlexAniList valide."}), 400
    if int(payload.get("version", 0)) not in (1, 2, BACKUP_VERSION):
        return jsonify({"ok": False, "error": "Version de sauvegarde non prise en charge."}), 400

    settings = payload.get("settings", [])
    libraries = payload.get("libraries", [])
    mappings = payload.get("mappings", [])
    seasons = payload.get("season_mappings", [])
    history = payload.get("history", [])
    legacy_token = ""
    if isinstance(settings, list):
        for setting in settings:
            if isinstance(setting, dict) and setting.get("cle") == "anilist_token":
                legacy_token = str(setting.get("valeur") or "").strip()
                break
    if not all(isinstance(x, list) for x in (settings, libraries, mappings, seasons, history)):
        return jsonify({"ok": False, "error": "Structure de sauvegarde invalide."}), 400

    # Remplacement complet : la sauvegarde représente l'état intégral de
    # l'application, pas seulement les paramètres. Aucun identifiant SQL n'est
    # restauré afin de laisser SQLite les régénérer proprement.
    try:
        SyncHistory.query.delete(synchronize_session=False)
        SeasonSyncTarget.query.delete(synchronize_session=False)
        AniListAccount.query.delete(synchronize_session=False)
        MappingRule.query.delete(synchronize_session=False)
        SeasonMapping.query.delete(synchronize_session=False)
        Mapping.query.delete(synchronize_session=False)
        Library.query.delete(synchronize_session=False)
        Setting.query.delete(synchronize_session=False)

        for row in settings:
            if not isinstance(row, dict) or not row.get("cle"):
                raise ValueError("Entrée de paramètre invalide")
            db.session.add(Setting(cle=str(row["cle"]), valeur=None if row.get("valeur") is None else str(row.get("valeur"))))

        for row in libraries:
            db.session.add(Library(
                id_plex=str(row.get("id_plex") or ""),
                nom=str(row.get("nom") or ""),
                activee=bool(row.get("activee", True)),
                type=row.get("type"),
            ))

        imported_accounts = {}
        for row in payload.get("anilist_accounts", []):
            if not isinstance(row, dict) or not row.get("nom") or not row.get("token"):
                continue
            created_at = None
            if row.get("created_at"):
                try:
                    created_at = datetime.fromisoformat(str(row["created_at"]).replace("Z", "+00:00")).replace(tzinfo=None)
                except ValueError:
                    created_at = None
            account = AniListAccount(nom=str(row["nom"]), token=str(row["token"]), actif=bool(row.get("actif", True)), created_at=created_at or datetime.utcnow())
            db.session.add(account)
            db.session.flush()
            imported_accounts[account.nom] = account.id

        for row in mappings:
            db.session.add(Mapping(
                titre_plex=str(row.get("titre_plex") or ""),
                anilist_id=row.get("anilist_id"),
                titre_anilist=row.get("titre_anilist"),
                image_anilist=row.get("image_anilist"),
                statut=str(row.get("statut") or "introuvable"),
                plex_rating_key=row.get("plex_rating_key"),
                plex_thumb=row.get("plex_thumb"),
                plex_year=row.get("plex_year"),
                tvdb_id=row.get("tvdb_id"),
                library_id_plex=row.get("library_id_plex"),
                dernier_episode_sync=row.get("dernier_episode_sync"),
            ))

        for row in payload.get("mapping_rules", []):
            try:
                db.session.add(MappingRule(
                    id=int(row.get("id")) if row.get("id") else None,
                    plex_rating_key=str(row.get("plex_rating_key") or ""),
                    plex_season_index=int(row.get("plex_season_index") or 0),
                    plex_episode_start=int(row.get("plex_episode_start") or 0),
                    plex_episode_end=int(row.get("plex_episode_end") or 0),
                    anilist_id=int(row.get("anilist_id") or 0),
                    anilist_episode_start=int(row.get("anilist_episode_start") or 1),
                    note=str(row.get("note") or "")[:500],
                ))
            except (TypeError, ValueError):
                continue

        for row in seasons:
            db.session.add(SeasonMapping(
                plex_rating_key=str(row.get("plex_rating_key") or ""),
                plex_season_index=int(row.get("plex_season_index") or 0),
                plex_season_rating_key=row.get("plex_season_rating_key"),
                titre_plex=str(row.get("titre_plex") or ""),
                titre_saison=row.get("titre_saison"),
                anilist_id=row.get("anilist_id"),
                titre_anilist=row.get("titre_anilist"),
                image_anilist=row.get("image_anilist"),
                statut=str(row.get("statut") or "non_lie"),
                dernier_episode_sync=row.get("dernier_episode_sync"),
                dernier_anilist_id_sync=row.get("dernier_anilist_id_sync"),
                anilist_episode_offset=row.get("anilist_episode_offset"),
            ))

        # Reconstituer les affectations par nom de compte, indépendamment des IDs SQL.
        for row in payload.get("season_sync_targets", []):
            if not isinstance(row, dict):
                continue
            sm = SeasonMapping.query.filter_by(
                plex_rating_key=str(row.get("plex_rating_key") or ""),
                plex_season_index=int(row.get("plex_season_index") or 0),
            ).first()
            aid = imported_accounts.get(str(row.get("account_name") or ""))
            if sm and aid:
                db.session.add(SeasonSyncTarget(
                    season_mapping_id=sm.id,
                    anilist_account_id=aid,
                    dernier_episode_sync=row.get("dernier_episode_sync"),
                    dernier_anilist_id_sync=row.get("dernier_anilist_id_sync"),
                ))

        # Les anciennes sauvegardes v1 n'ont pas de liste de comptes. Le token
        # a été capturé depuis le fichier avant la suppression de la base.
        if not imported_accounts:
            legacy_token = legacy_token or ""
            if legacy_token:
                account = AniListAccount(nom="Compte principal", token=legacy_token, actif=True)
                db.session.add(account)
                db.session.flush()
                for sm in SeasonMapping.query.filter(SeasonMapping.anilist_id.isnot(None)).all():
                    db.session.add(SeasonSyncTarget(season_mapping_id=sm.id, anilist_account_id=account.id))

        for row in history:
            dt = None
            if row.get("date"):
                try:
                    dt = datetime.fromisoformat(str(row["date"]).replace("Z", "+00:00")).replace(tzinfo=None)
                except ValueError:
                    dt = datetime.utcnow()
            db.session.add(SyncHistory(
                date=dt or datetime.utcnow(),
                titre=str(row.get("titre") or ""),
                episode=row.get("episode"),
                statut=str(row.get("statut") or "erreur"),
                message=row.get("message"),
            ))

        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        return jsonify({"ok": False, "error": f"Import impossible : {exc}"}), 400

    return jsonify({
        "ok": True,
        "counts": {
            "settings": len(settings),
            "libraries": len(libraries),
            "mappings": len(mappings),
            "seasons": len(seasons),
            "history": len(history),
            "accounts": len(imported_accounts),
        },
    })


# ----------------- Lancement -----------------
if __name__ == "__main__":
    from waitress import serve
    serve(app, host=Config.HOST, port=Config.PORT, threads=4)

"""
Client AniList : fonctions utilitaires pour interroger l'API GraphQL v2.

Documentation : https://docs.anilist.co/
Rate limiting  : https://docs.anilist.co/guide/rate-limiting
  L'API AniList tourne actuellement en mode dégradé à 30 requêtes/minute
  (au lieu de 90 en temps normal). En cas de dépassement elle répond 429
  avec un en-tête `Retry-After` : on l'honore ici avec une seule attente
  automatique plutôt que de spammer à nouveau immédiatement.
"""

import time

import requests

ANILIST_API = "https://graphql.anilist.co"


class AniListError(Exception):
    pass


def _post(query, variables, token=None, timeout=10, _retried=False):
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.post(
            ANILIST_API,
            json={"query": query, "variables": variables},
            headers=headers,
            timeout=timeout,
        )
    except requests.RequestException as e:
        raise AniListError(f"Connexion AniList impossible: {e}")

    if r.status_code == 429 and not _retried:
        # On respecte Retry-After (plafonné à 60s pour ne pas bloquer indéfiniment
        # un thread de fond) puis on retente une seule fois.
        wait = min(float(r.headers.get("Retry-After", 5)), 60)
        time.sleep(wait)
        return _post(query, variables, token=token, timeout=timeout, _retried=True)

    if r.status_code == 429:
        raise AniListError("Limite de débit AniList dépassée (429), réessayez plus tard")

    if r.status_code == 401:
        raise AniListError("Token AniList refusé (401) — vérifiez le token dans les Paramètres")

    if r.status_code != 200:
        raise AniListError(f"AniList a répondu {r.status_code}: {r.text[:200]}")

    data = r.json()
    if "errors" in data and data["errors"]:
        raise AniListError(f"AniList erreurs: {data['errors'][0].get('message')}")
    return data.get("data", {})


def get_media_by_id(anilist_id, token=None):
    """Récupère un anime AniList à partir de son identifiant numérique."""
    try:
        anilist_id = int(anilist_id)
    except (TypeError, ValueError):
        raise AniListError("Identifiant AniList invalide")
    if anilist_id <= 0:
        raise AniListError("Identifiant AniList invalide")

    gql = """
    query ($id: Int) {
      Media(id: $id, type: ANIME) {
        id
        type
        episodes
        title { romaji english native }
        synonyms
        coverImage { medium large }
      }
    }
    """
    data = _post(gql, {"id": anilist_id}, token=token)
    media = data.get("Media") or {}
    if not media or media.get("type") != "ANIME":
        return None
    title = media.get("title") or {}
    cover = media.get("coverImage") or {}
    return {
        "id": media.get("id"),
        "title": title.get("english") or title.get("romaji") or title.get("native") or "(sans titre)",
        "image": cover.get("large") or cover.get("medium"),
        "title_romaji": title.get("romaji"),
        "title_english": title.get("english"),
        "title_native": title.get("native"),
        "synonyms": media.get("synonyms") or [],
        "episodes": media.get("episodes"),
    }


def search_media(query, token=None):
    """Recherche un anime par titre.

    Retourne une liste [{id, title, image, title_romaji, title_english,
    title_native, synonyms, episodes}, ...]. Les champs title_* / synonyms
    servent au matching automatique (scanner de mapping) ; `episodes` sert à
    l'option "marquer terminé au dernier épisode".
    """
    gql = """
    query ($search: String) {
      Page(perPage: 10) {
        media(search: $search, type: ANIME) {
          id
          type
          episodes
          title { romaji english native }
          synonyms
          relations { edges { relationType node { id type episodes title { romaji english native } synonyms coverImage { medium large } } } }
          coverImage { medium large }
        }
      }
    }
    """
    data = _post(gql, {"search": query}, token=token)
    out = []
    for m in (data.get("Page") or {}).get("media") or []:
        if not m or m.get("type", "ANIME") != "ANIME":
            continue
        title = (m.get("title") or {})
        cover = (m.get("coverImage") or {})
        out.append({
            "id": m.get("id"),
            "title": title.get("english") or title.get("romaji") or "(sans titre)",
            "image": cover.get("large") or cover.get("medium"),
            "title_romaji": title.get("romaji"),
            "title_english": title.get("english"),
            "title_native": title.get("native"),
            "synonyms": m.get("synonyms") or [],
            "episodes": m.get("episodes"),
            "relations": [
                {
                    "relation_type": e.get("relationType"),
                    "type": (e.get("node") or {}).get("type"),
                    "episodes": (e.get("node") or {}).get("episodes"),
                    "id": (e.get("node") or {}).get("id"),
                    "title": ((e.get("node") or {}).get("title") or {}).get("english") or ((e.get("node") or {}).get("title") or {}).get("romaji"),
                    "title_romaji": ((e.get("node") or {}).get("title") or {}).get("romaji"),
                    "title_english": ((e.get("node") or {}).get("title") or {}).get("english"),
                    "synonyms": (e.get("node") or {}).get("synonyms") or [],
                    "image": ((e.get("node") or {}).get("coverImage") or {}).get("large") or ((e.get("node") or {}).get("coverImage") or {}).get("medium"),
                }
                for e in ((m.get("relations") or {}).get("edges") or [])
                if e.get("node") and (e.get("node") or {}).get("type") == "ANIME"
            ],
        })
    return out



def _search_query_variants(query):
    """Construit quelques variantes de recherche sans multiplier inutilement les appels.

    AniList expose les synonymes dans les résultats, mais la recherche initiale ne
    ramène pas toujours un média lorsque Plex utilise uniquement son titre français.
    On ajoute donc une variante composée des mots significatifs du titre.
    """
    import re
    import unicodedata

    raw = (query or "").strip()
    if not raw:
        return []
    out = [raw]
    cleaned = re.sub(r"[\[\]{}()]+", " ", raw)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    if cleaned and cleaned.casefold() != raw.casefold():
        out.append(cleaned)

    no_accents = "".join(
        c for c in unicodedata.normalize("NFKD", cleaned)
        if not unicodedata.combining(c)
    )
    if no_accents and no_accents.casefold() not in {x.casefold() for x in out}:
        out.append(no_accents)

    stop = {
        "le", "la", "les", "un", "une", "des", "de", "du", "au", "aux",
        "et", "ou", "a", "à", "en", "dans", "sur", "pour", "avec",
        "the", "a", "an", "of", "and", "in", "on", "season", "saison",
    }
    words = [w for w in re.findall(r"[\wÀ-ÿ]+", cleaned.lower()) if w not in stop and len(w) >= 3]
    if len(words) >= 2:
        # Les mots les plus longs sont généralement les plus discriminants pour
        # les titres français, tout en restant compatibles avec AniList search.
        significant = sorted(set(words), key=lambda w: (-len(w), w))[:4]
        phrase = " ".join(significant)
        if phrase and phrase.casefold() not in {x.casefold() for x in out}:
            out.append(phrase)
    return out[:4]


def search_media_variants(query, token=None):
    """Recherche AniList avec le titre complet et quelques variantes ciblées."""
    merged = {}
    for q in _search_query_variants(query):
        for item in search_media(q, token=token):
            if item.get("id"):
                merged[int(item["id"])] = item
    return list(merged.values())

def search_season_media(series_title, season_index, season_title=None, query=None, token=None):
    """Recherche des candidats pour une saison.

    Pour la saison 1, la requête principale reste volontairement le titre de la
    série : sur AniList, « Season 1 » est très souvent absent du titre. Pour les
    saisons suivantes, on ajoute aussi une requête explicite avec le numéro.
    Les résultats sont fusionnés et les relations AniList sont parcourues afin
    de retrouver les suites même lorsque leur titre ne contient pas « Saison 2 ».
    """
    base = (query or series_title or '').strip()
    if not base:
        return []
    queries = _search_query_variants(base)
    if season_index > 1:
        queries += [f"{base} Season {season_index}", f"{base} {season_index}"]
    elif season_title and season_title.strip() and season_title.strip().lower() not in {base.lower(), 'season 1', 'saison 1'}:
        queries.append(f"{base} {season_title.strip()}")

    merged = {}
    for q in queries[:7]:
        for item in search_media(q, token=token):
            if item.get('id'):
                merged[int(item['id'])] = item

    # Ajouter les relations des premiers résultats : utile pour une saison 2/3
    # dont le titre est complètement différent de celui de la saison 1.
    seeds = list(merged.values())[:10]
    for item in seeds:
        for rel in item.get('relations') or []:
            if rel.get('id') and rel.get('type') == 'ANIME' and rel.get('relation_type') in {'SEQUEL','PREQUEL','ALTERNATIVE','SIDE_STORY'}:
                rid = int(rel['id'])
                if rid not in merged:
                    merged[rid] = rel
    return list(merged.values())


def get_episode_count(anilist_id, token=None):
    """Retourne le nombre total d'épisodes d'un média AniList (ou None si inconnu,
    par exemple une série encore en diffusion sans total fixé)."""
    gql = """
    query ($id: Int) {
      Media(id: $id, type: ANIME) {
        episodes
      }
    }
    """
    data = _post(gql, {"id": int(anilist_id)}, token=token)
    media = data.get("Media") or {}
    return media.get("episodes")


def update_progress(anilist_id, episode, token, mark_completed=False):
    """Met à jour la progression et le statut d'une entrée AniList.

    Dès qu'un épisode est synchronisé, l'anime est placé en `CURRENT`
    ("Watching" dans l'interface AniList). Si `mark_completed` est vrai et
    que l'épisode synchronisé est le dernier, le statut devient `COMPLETED`.
    """
    if not token:
        raise AniListError("Aucun token AniList configuré")
    if not anilist_id or not episode:
        raise AniListError("anilist_id ou episode manquant")

    # Un épisode ajouté/synchronisé signifie que l'anime est actuellement
    # regardé. On force donc CURRENT au lieu de laisser AniList conserver un
    # éventuel statut PLANNING, PAUSED, DROPPED, etc.
    status = "CURRENT"
    if mark_completed:
        try:
            total = get_episode_count(anilist_id, token=token)
            if total and int(episode) >= int(total):
                status = "COMPLETED"
        except AniListError:
            # Non bloquant : on synchronise quand même l'épisode en CURRENT.
            pass

    gql = """
    mutation ($id: Int, $progress: Int, $status: MediaListStatus) {
      SaveMediaListEntry(mediaId: $id, progress: $progress, status: $status) {
        id
        progress
        status
      }
    }
    """
    variables = {
        "id": int(anilist_id),
        "progress": int(episode),
        "status": status,
    }

    data = _post(gql, variables, token=token)
    if not data.get("SaveMediaListEntry"):
        raise AniListError("Réponse SaveMediaListEntry vide")
    return data["SaveMediaListEntry"]

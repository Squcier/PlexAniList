"""Pont léger entre les identifiants TheTVDB et AniList.

Le service idmapper est utilisé uniquement comme table de correspondance :
Plex/TheTVDB -> AniList. Si le service est indisponible, le mapping par titres
reste disponible.
"""
import time
import requests

BASE_URL = "https://idmapper.vercel.app/api/mapper"
_CACHE = {}
_CACHE_TTL = 86400

class IDMapperError(Exception):
    pass


def lookup_tvdb(tvdb_id, timeout=8):
    try:
        tvdb_id = int(tvdb_id)
    except (TypeError, ValueError):
        raise IDMapperError("Identifiant TheTVDB invalide")
    now = time.time()
    cached = _CACHE.get(tvdb_id)
    if cached and now - cached[0] < _CACHE_TTL:
        return cached[1]
    try:
        r = requests.get(BASE_URL, params={"thetvdb_id": tvdb_id}, timeout=timeout)
    except requests.RequestException as e:
        raise IDMapperError(f"Service de correspondance indisponible: {e}")
    if r.status_code != 200:
        raise IDMapperError(f"Service de correspondance HTTP {r.status_code}")
    try:
        data = r.json()
    except ValueError:
        raise IDMapperError("Réponse de correspondance invalide")
    if not data or not data.get("anilist_id"):
        raise IDMapperError(f"Aucune correspondance AniList pour TheTVDB {tvdb_id}")
    _CACHE[tvdb_id] = (now, data)
    return data


def season_episode_offset(mapping, season_index):
    """Retourne le décalage vers la numérotation absolue AniList.

    Les données TVDB sont de la forme s1=e1-e61, s2=e1-e22, etc. Pour une
    saison, on additionne les épisodes des saisons précédentes connues.
    """
    if not isinstance(mapping, dict):
        return None
    tvdb_map = mapping.get("tvdb_mappings") or {}
    try:
        target = int(season_index)
    except (TypeError, ValueError):
        return None
    if target <= 0:
        return None
    total = 0
    for idx in range(1, target):
        raw = tvdb_map.get(f"s{idx}")
        if not raw:
            return None
        end = _range_end(raw)
        if end is None:
            return None
        total += end
    return total


def _range_end(raw):
    import re
    m = re.search(r"e\d+\s*-\s*e(\d+)", str(raw), re.I)
    if m:
        return int(m.group(1))
    m = re.search(r"e(\d+)", str(raw), re.I)
    return int(m.group(1)) if m else None

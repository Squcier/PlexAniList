"""
Client Plex : encapsule les appels HTTP vers l'API Plex.

Toutes les fonctions retournent des structures Python simples (listes / dicts)
et lèvent une exception `PlexError` en cas d'échec réseau ou HTTP non-200.

Le token est envoyé en en-tête HTTP (X-Plex-Token) plutôt qu'en paramètre
d'URL : c'est la pratique recommandée par Plex pour éviter qu'il ne se
retrouve dans des logs d'accès ou des historiques de proxy.
"""

import time
import xml.etree.ElementTree as ET
import re

import requests

_MAX_RETRIES = 2
_RETRY_BACKOFF = 0.8  # secondes, doublé à chaque tentative


class PlexError(Exception):
    pass


def _base(plex_url):
    if not plex_url or not (plex_url.startswith("http://") or plex_url.startswith("https://")):
        raise PlexError("URL Plex invalide (doit commencer par http:// ou https://)")
    return plex_url.rstrip("/")


def _get(url, plex_token, params=None, timeout=5):
    """GET avec le token en en-tête + quelques tentatives en cas d'erreur réseau
    transitoire (le serveur Plex local peut être temporairement occupé)."""
    headers = {"X-Plex-Token": plex_token, "Accept": "application/xml"}
    last_err = None
    for attempt in range(_MAX_RETRIES + 1):
        try:
            return requests.get(url, params=params, headers=headers, timeout=timeout)
        except requests.RequestException as e:
            last_err = e
            if attempt < _MAX_RETRIES:
                time.sleep(_RETRY_BACKOFF * (2 ** attempt))
    raise PlexError(f"Connexion Plex impossible: {last_err}")


def list_libraries(plex_url, plex_token, timeout=5):
    """Retourne la liste des bibliothèques Plex sous forme [{id_plex, nom, type}, ...]."""
    url = f"{_base(plex_url)}/library/sections"
    r = _get(url, plex_token, timeout=timeout)

    if r.status_code == 401:
        raise PlexError("Token Plex refusé (401) — vérifiez le token dans les Paramètres")
    if r.status_code != 200:
        raise PlexError(f"Plex a répondu {r.status_code}")

    try:
        root = ET.fromstring(r.text)
        out = []
        for d in root.iter("Directory"):
            out.append({
                "id_plex": d.get("key") or d.get("id"),
                "nom": d.get("title") or "(sans nom)",
                "type": d.get("type"),
            })
        return out
    except ET.ParseError as e:
        raise PlexError(f"Réponse Plex invalide: {e}")


def list_series(plex_url, plex_token, section_id, timeout=8):
    """Retourne toutes les séries d'une bibliothèque Plex (type 'show').

    Chaque élément : {rating_key, titre, annee, thumb} où `thumb` est un
    chemin relatif (à préfixer par l'URL du serveur + le token pour l'afficher).
    """
    url = f"{_base(plex_url)}/library/sections/{section_id}/all"
    r = _get(url, plex_token, params={"type": "2"}, timeout=timeout)  # type=2 -> shows

    if r.status_code == 401:
        raise PlexError("Token Plex refusé (401) — vérifiez le token dans les Paramètres")
    if r.status_code != 200:
        raise PlexError(f"Plex /library/sections/{section_id}/all a répondu {r.status_code}")

    try:
        root = ET.fromstring(r.text)
        out = []
        for d in root.iter("Directory"):
            rating_key = d.get("ratingKey")
            if not rating_key:
                continue
            annee = d.get("year")
            tvdb_id = None
            for g in d.findall("Guid"):
                gid = g.get("id") or ""
                m = re.search(r"(?:thetvdb|tvdb)://(\d+)", gid, re.I)
                if m:
                    tvdb_id = int(m.group(1))
                    break
            out.append({
                "rating_key": rating_key,
                "titre": d.get("title") or "(sans titre)",
                "annee": int(annee) if annee and annee.isdigit() else None,
                "thumb": d.get("thumb"),
                "tvdb_id": tvdb_id,
            })
        return out
    except ET.ParseError as e:
        raise PlexError(f"Réponse séries Plex invalide: {e}")



def list_seasons(plex_url, plex_token, series_rating_key, timeout=8):
    """Retourne les saisons d'une série Plex.

    Chaque élément contient l'index de saison, son ratingKey, son titre,
    sa miniature et le nombre d'épisodes connus par Plex.
    """
    url = f"{_base(plex_url)}/library/metadata/{series_rating_key}/children"
    r = _get(url, plex_token, timeout=timeout)
    if r.status_code == 401:
        raise PlexError("Token Plex refusé (401) — vérifiez le token dans les Paramètres")
    if r.status_code != 200:
        raise PlexError(f"Plex /library/metadata/{series_rating_key}/children a répondu {r.status_code}")
    try:
        root = ET.fromstring(r.text)
        out = []
        for d in root.iter("Directory"):
            idx = d.get("index")
            if not idx or not idx.isdigit():
                continue
            out.append({
                "season_index": int(idx),
                "rating_key": d.get("ratingKey"),
                "titre": d.get("title") or f"Saison {idx}",
                "thumb": d.get("thumb"),
                "episodes": int(d.get("leafCount") or 0),
            })
        return sorted(out, key=lambda x: x["season_index"])
    except ET.ParseError as e:
        raise PlexError(f"Réponse saisons Plex invalide: {e}")


def get_machine_identifier(plex_url, plex_token, timeout=5):
    """Récupère l'identifiant unique du serveur Plex (nécessaire pour construire
    des liens cliquables vers l'interface web de Plex)."""
    url = f"{_base(plex_url)}/identity"
    r = _get(url, plex_token, timeout=timeout)

    if r.status_code != 200:
        raise PlexError(f"Plex /identity a répondu {r.status_code}")

    try:
        root = ET.fromstring(r.text)
        mid = root.get("machineIdentifier")
        if not mid:
            raise PlexError("machineIdentifier absent de la réponse Plex")
        return mid
    except ET.ParseError as e:
        raise PlexError(f"Réponse /identity invalide: {e}")


def get_sessions(plex_url, plex_token, timeout=5):
    """Retourne la liste des sessions actives.

    Chaque élément contient désormais aussi `type` ("episode", "movie", ...)
    et `state` ("playing", "paused", "buffering") afin que l'appelant puisse
    filtrer précisément ce qu'il souhaite synchroniser.
    """
    url = f"{_base(plex_url)}/status/sessions"
    r = _get(url, plex_token, timeout=timeout)

    if r.status_code == 401:
        raise PlexError("Token Plex refusé (401) — vérifiez le token dans les Paramètres")
    if r.status_code != 200:
        raise PlexError(f"Plex /status/sessions a répondu {r.status_code}")

    try:
        root = ET.fromstring(r.text)
        sessions = []
        for s in root.iter("Video"):
            view_offset = int(s.get("viewOffset") or 0)
            duration = int(s.get("duration") or 0)
            progress = (view_offset / duration * 100) if duration > 0 else 0
            grand_parent = s.get("grandparentTitle") or ""  # nom de la série
            title = s.get("title") or ""                    # titre de l'épisode
            episode_index = s.get("index")                  # numéro d'épisode

            player = s.find("Player")
            state = player.get("state") if player is not None else None

            sessions.append({
                "titre_plex": grand_parent or title,
                "episode": int(episode_index) if (episode_index and episode_index.isdigit()) else None,
                "absolute_episode": int(s.get("absoluteIndex")) if (s.get("absoluteIndex") or "").isdigit() else None,
                "season": int(s.get("parentIndex")) if (s.get("parentIndex") or "").isdigit() else None,
                "series_rating_key": s.get("grandparentRatingKey"),
                "view_offset": view_offset,
                "duration": duration,
                "progress": round(progress, 2),
                "type": s.get("type"),   # "episode", "movie", "clip", ...
                "state": state,          # "playing", "paused", "buffering"
            })
        return sessions
    except ET.ParseError as e:
        raise PlexError(f"Réponse sessions Plex invalide: {e}")

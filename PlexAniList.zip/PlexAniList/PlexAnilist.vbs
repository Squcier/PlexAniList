Option Explicit

Dim fso, shell, appDir, pythonw, script, command
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

appDir = fso.GetParentFolderName(WScript.ScriptFullName)
script = fso.BuildPath(appDir, "PlexAniList.py")

' Utilise pythonw.exe pour lancer l'application sans fenêtre de console.
' Un environnement virtuel local est privilégié s'il existe.
pythonw = fso.BuildPath(appDir, ".venv\Scripts\pythonw.exe")
If Not fso.FileExists(pythonw) Then
    pythonw = "pythonw.exe"
End If

command = """" & pythonw & """ """ & script & """"
shell.CurrentDirectory = appDir
shell.Run command, 0, False

Set shell = Nothing
Set fso = Nothing

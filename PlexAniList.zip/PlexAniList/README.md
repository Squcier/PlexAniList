# PlexAniList

Synchronisation Plex → AniList avec interface Web Flask.

## Démarrage normal

Double-cliquer sur **`PlexAniList.vbs`**.

Le script lance l'application Web avec `pythonw.exe` : **aucune fenêtre Python/console n'est affichée**.  
L'interface reste disponible dans le navigateur à :

`http://127.0.0.1:6060`

Si un environnement virtuel local existe dans `.venv`, son `pythonw.exe` est utilisé en priorité.

## Démarrage manuel

Pour lancer l'application depuis un terminal :

```bash
python app.py
```

Puis ouvrir `http://127.0.0.1:6060`.

## Configuration

La configuration Plex/AniList se fait depuis la page **Paramètres** de l'interface Web.

La base SQLite (`PlexAniList.db`) et la clé secrète locale (`.secret_key`) sont créées automatiquement au premier démarrage.

La synchronisation concerne uniquement les bibliothèques activées. Si aucune
bibliothèque n'est active, rien n'est envoyé à AniList. La conversion des
épisodes utilise uniquement le décalage positif ou négatif réglé sur chaque
saison. L'historique conserve les 10 000 événements les plus récents.

Pour installer les dépendances après extraction :

```bash
python -m pip install -r requirements.txt
```

## Comptes AniList multiples

La configuration permet désormais d'enregistrer plusieurs tokens AniList sous des noms distincts. Dans **Mapping**, une saison peut être affectée à plusieurs comptes ; chaque compte reçoit alors la mise à jour de progression. Les affectations peuvent être modifiées individuellement par saison ou en masse en sélectionnant plusieurs séries.

/* Mapping : une série est uniquement un conteneur. Les liaisons AniList sont faites saison par saison. */
(async function () {
  const tbody = document.querySelector('#mapping-table tbody');
  const modal = document.getElementById('search-modal');
  const modalTitle = modal.querySelector('h3');
  const input = document.getElementById('anilist-search-input');
  const results = document.getElementById('anilist-results');
  const cancel = document.getElementById('search-cancel');
  const scanBtn = document.getElementById('scan-btn');
  const scanStatus = document.getElementById('scan-status');
  const progressWrap = document.getElementById('scan-progress-wrap');
  const progressFill = document.getElementById('scan-progress-fill');
  const confirmModal = document.getElementById('action-confirm-modal');
  const confirmTitle = document.getElementById('action-confirm-title');
  const confirmMessage = document.getElementById('action-confirm-message');
  const confirmCancel = document.getElementById('action-confirm-cancel');
  const confirmOk = document.getElementById('action-confirm-ok');
  const idInput = document.getElementById('anilist-id-input');
  const idApply = document.getElementById('anilist-id-apply');
  const idResult = document.getElementById('anilist-id-result');
  const rulesModal = document.getElementById('rules-modal');
  const rulesContext = document.getElementById('rules-context');
  const seasonOffsetCurrent = document.getElementById('season-offset-current');
  const seasonOffsetInput = document.getElementById('season-offset-input');
  const seasonOffsetPreview = document.getElementById('season-offset-preview');
  const seasonOffsetSave = document.getElementById('season-offset-save');
  const seasonOffsetDelete = document.getElementById('season-offset-delete');
  const seasonOffsetResult = document.getElementById('season-offset-result');
  const accountsModal = document.getElementById('accounts-modal');
  const accountsModalTitle = document.getElementById('accounts-modal-title');
  const accountsModalContext = document.getElementById('accounts-modal-context');
  const accountsModalTags = document.getElementById('accounts-modal-tags');
  const accountsModalSelect = document.getElementById('accounts-modal-select');
  const accountsModalAdd = document.getElementById('accounts-modal-add');
  const accountsModalSave = document.getElementById('accounts-modal-save');
  const accountsModalCancel = document.getElementById('accounts-modal-cancel');
  const accountsModalClose = document.getElementById('accounts-modal-close');
  let accountsModalKeys = [];
  let accountsModalSelected = [];

  let currentTarget = null;
  let currentRuleParent = null;
  let allRows = [];
  let searchTimer = null;
  let pollTimer = null;
  let anilistAccounts = [];

  const STATUT_LABELS = {auto:'Auto', manuel:'Manuel', a_verifier:'À vérifier', introuvable:'Introuvable', non_lie:'Non lié', ignore:'Ignoré'};
  const esc = s => String(s == null ? '' : s).replace(/[<>&"']/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&#39;'}[c]));

  function askConfirmation({title, message, confirmLabel='Confirmer', danger=false}) {
    return new Promise(resolve => {
      confirmTitle.textContent = title;
      confirmMessage.textContent = message;
      confirmOk.textContent = confirmLabel;
      confirmOk.classList.toggle('danger', !!danger);
      confirmModal.classList.remove('hidden');

      const finish = value => {
        confirmModal.classList.add('hidden');
        confirmOk.classList.remove('danger');
        confirmCancel.onclick = null;
        confirmOk.onclick = null;
        confirmModal.onclick = null;
        resolve(value);
      };

      confirmCancel.onclick = () => finish(false);
      confirmOk.onclick = () => finish(true);
      confirmModal.onclick = e => {
        if (e.target === confirmModal) finish(false);
      };
    });
  }

  function selectedRows() {
    const selectedKeys = new Set(
      [...tbody.querySelectorAll('.mapping-select:checked')].map(cb => cb.dataset.key).filter(Boolean)
    );
    return filteredRows().filter(r => selectedKeys.has(r.plex_rating_key));
  }

  function syncSelectAll() {
    const boxes = [...tbody.querySelectorAll('.mapping-select')];
    const checked = boxes.filter(cb => cb.checked).length;
    const selectAll = document.getElementById('select-all');
    selectAll.checked = boxes.length > 0 && checked === boxes.length;
    selectAll.indeterminate = checked > 0 && checked < boxes.length;
  }

  async function load() {
    const ar = await fetch('/api/anilist/accounts');
    const ad = await ar.json().catch(() => ({}));
    anilistAccounts = ad.accounts || [];
    const r = await fetch('/api/mapping');
    const data = await r.json();
    allRows = data.rows || [];
    const lib = document.getElementById('filter-library');
    const previous = lib.value;
    const libs = [...new Set(allRows.map(x => x.library_id_plex).filter(Boolean))];
    lib.innerHTML = '<option value="">Toutes les bibliothèques</option>' + libs.map(id => {
      const row = allRows.find(x => x.library_id_plex === id);
      return `<option value="${esc(id)}">${esc(row ? row.library_name : id)}</option>`;
    }).join('');
    lib.value = previous;
    applyFilters();
  }

  function filteredRows() {
    const q = document.getElementById('filter-search').value.trim().toLocaleLowerCase();
    const status = document.getElementById('filter-status').value;
    const library = document.getElementById('filter-library').value;
    return allRows.filter(r =>
      (!q || (r.titre_plex || '').toLocaleLowerCase().includes(q)) &&
      (!status || r.statut === status) &&
      (!library || r.library_id_plex === library)
    );
  }
  function applyFilters() { render(filteredRows()); }
  ['filter-search','filter-status','filter-library'].forEach(id => document.getElementById(id).addEventListener('input', applyFilters));
  document.querySelectorAll('.filter-tab').forEach(tab => tab.addEventListener('click', () => {
    document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById('filter-status').value = tab.dataset.status || '';
    applyFilters();
  }));

  function primaryAccount() { return anilistAccounts.length ? anilistAccounts.slice().sort((a,b) => Number(a.id) - Number(b.id))[0] : null; }

  function accountOptions(selectedIds, placeholder='Ajouter…') {
    const selected = new Set((selectedIds || []).map(Number));
    const primary = primaryAccount();
    return `<option value="">${esc(placeholder)}</option>` + anilistAccounts
      .filter(a => a.actif && (!primary || Number(a.id) !== Number(primary.id)) && !selected.has(Number(a.id)))
      .map(a => `<option value="${esc(a.id)}">${esc(a.nom)}</option>`).join('');
  }

  function accountTags(accounts, removable=true) {
    const primary = primaryAccount();
    // Le compte principal est implicite : il ne doit jamais apparaître dans le mapping.
    const ordered = [...(accounts || [])]
      .filter(a => !primary || Number(a.id) !== Number(primary.id))
      .sort((a,b) => Number(a.id) - Number(b.id));
    return ordered.map(a =>
      `<span class="account-chip" data-account-id="${esc(a.id)}"><span>${esc(a.nom)}</span>${removable ? `<button type="button" class="account-chip-remove" data-account-id="${esc(a.id)}" aria-label="Retirer ${esc(a.nom)}">×</button>` : ''}</span>`
    ).join('');
  }

  async function saveSeriesAccounts(key, ids) {
    const r = await fetch('/api/mapping/series-accounts', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({plex_rating_keys:[key],account_ids:ids})});
    const d = await r.json().catch(()=>({}));
    if (!r.ok || !d.ok) throw new Error(d.error || 'Affectation impossible');
    const row = allRows.find(x => x.plex_rating_key === key);
    if (row) {
      row.sync_account_ids = [...ids];
      row.sync_accounts = anilistAccounts.filter(a => ids.includes(Number(a.id))).map(a => ({id:a.id,nom:a.nom}));
    }
    return d;
  }

  function bindSeriesAccountPicker(rowEl, r) {
    const select = rowEl.querySelector('.series-account-select');
    const tags = rowEl.querySelector('.series-account-tags');
    const refresh = () => {
      const ids = (r.sync_account_ids || []).map(Number);
      tags.innerHTML = accountTags(r.sync_accounts || []);
      select.innerHTML = accountOptions(ids, 'Ajouter…');
      rowEl.querySelectorAll('.account-chip-remove').forEach(btn => btn.addEventListener('click', async () => {
        const next = ids.filter(id => id !== Number(btn.dataset.accountId));
        try { await saveSeriesAccounts(r.plex_rating_key, next); r.sync_account_ids = next; r.sync_accounts = anilistAccounts.filter(a => next.includes(Number(a.id))).map(a => ({id:a.id,nom:a.nom})); refresh(); }
        catch(e) { alert(e.message); }
      }));
    };
    const addSelected = async () => {
      const id = Number(select.value);
      if (!id) return;
      const next = [...new Set([...(r.sync_account_ids || []).map(Number), id])];
      try { select.disabled = true; await saveSeriesAccounts(r.plex_rating_key, next); r.sync_account_ids = next; r.sync_accounts = anilistAccounts.filter(a => next.includes(Number(a.id))).map(a => ({id:a.id,nom:a.nom})); refresh(); }
      catch(e) { alert(e.message); } finally { select.disabled = false; }
    };
    select.addEventListener('change', addSelected);
    refresh();
  }

  function openAccountsModal(keys, existingIds=null) {
    accountsModalKeys = keys;
    const merged = existingIds || [...new Set(keys.flatMap(k => { const r=allRows.find(x=>x.plex_rating_key===k); return (r?.sync_account_ids||[]).map(Number); }))];
    accountsModalSelected = [...new Set(merged)];
    accountsModalTitle.textContent = keys.length > 1 ? 'Affecter les comptes AniList' : 'Comptes AniList';
    accountsModalContext.textContent = keys.length > 1 ? `${keys.length} série(s) sélectionnée(s)` : 'Choisis les comptes qui recevront les mises à jour de cette série.';
    renderAccountsModal();
    accountsModal.classList.remove('hidden');
  }

  function renderAccountsModal() {
    accountsModalTags.innerHTML = accountTags(anilistAccounts.filter(a => accountsModalSelected.includes(Number(a.id))).map(a => ({id:a.id,nom:a.nom})));
    accountsModalSelect.innerHTML = accountOptions(accountsModalSelected);
    accountsModalTags.querySelectorAll('.account-chip-remove').forEach(btn => btn.addEventListener('click', () => {
      accountsModalSelected = accountsModalSelected.filter(id => id !== Number(btn.dataset.accountId));
      renderAccountsModal();
    }));
  }

  function closeAccountsModal() { accountsModal.classList.add('hidden'); }

  function seriesHtml(r) {
    return `<tr class="series-row" data-key="${esc(r.plex_rating_key || '')}">
      <td><input type="checkbox" class="mapping-select" data-key="${esc(r.plex_rating_key || '')}" aria-label="Sélectionner ${esc(r.titre_plex)}"></td>
      <td class="mapping-pair-cell">
        <div class="mapping-pair">
          <button class="season-toggle" title="Afficher les saisons" data-key="${esc(r.plex_rating_key || '')}" aria-expanded="false">›</button>
          <div class="mapping-item plex-item">${r.plex_thumb_url ? `<img src="${esc(r.plex_thumb_url)}" class="mapping-cover" alt="">` : '<div class="mapping-cover-placeholder">—</div>'}<div class="mapping-meta"><div class="mapping-title">${esc(r.titre_plex)}</div>${r.plex_year ? `<div class="muted small">${r.plex_year}</div>` : ''}</div></div>
          <div class="mapping-connector">↳</div>
          <div class="season-summary"><strong>Liaisons par saison</strong><span class="muted small">${esc(r.season_linked_count || 0)}/${esc(r.season_count || 0)} saison(s) liée(s)</span></div>
        </div>
        <div class="series-account-picker">
          <div class="account-picker-inline"><select class="series-account-select" aria-label="Ajouter un compte AniList"></select></div>
          <div class="series-account-tags account-tags-editor"></div>
        </div>
      </td>
      <td class="status-cell"><span class="status-pill ${esc(r.statut || 'non_lie')}">${esc(STATUT_LABELS[r.statut] || 'Saisons')}</span></td>
      <td class="verify-cell"><div class="verify-links">${r.plex_link ? `<a href="${esc(r.plex_link)}" target="_blank" rel="noopener" class="link-btn">Plex</a>` : ''}${r.tvdb_id ? `<a href="https://www.thetvdb.com/series/${encodeURIComponent(r.tvdb_id)}" target="_blank" rel="noopener" class="link-btn">TheTVDB</a>` : ''}</div></td>
      <td class="actions-cell"><div class="row-actions"><button class="btn-primary search-series" data-key="${esc(r.plex_rating_key || '')}">Rechercher les saisons</button><button class="btn-secondary toggle-ignore" data-titre="${esc(r.titre_plex)}">${r.statut === 'ignore' ? 'Réactiver' : 'Ignorer'}</button><button class="btn-secondary danger delete-mapping" data-titre="${esc(r.titre_plex)}">Supprimer</button></div></td>
    </tr>`;
  }

  function render(rows) {
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="5" class="muted empty-mapping">Aucun mapping pour l\'instant. Cliquez sur « Scanner les bibliothèques ».</td></tr>';
      const selectAll = document.getElementById('select-all');
      selectAll.checked = false;
      selectAll.indeterminate = false;
      return;
    }
    tbody.innerHTML = rows.map(seriesHtml).join('');
    bindSeriesActions();
  }

  function bindSeriesActions() {
    tbody.querySelectorAll('.season-toggle').forEach(btn => btn.addEventListener('click', () => toggleSeasons(btn)));
    tbody.querySelectorAll('.series-row').forEach(rowEl => { const r = allRows.find(x => x.plex_rating_key === rowEl.dataset.key); if (r) bindSeriesAccountPicker(rowEl, r); });

    tbody.querySelectorAll('.mapping-select').forEach(cb => {
      cb.addEventListener('change', syncSelectAll);
    });

    tbody.querySelectorAll('.search-series').forEach(btn => btn.addEventListener('click', async () => {
      btn.disabled = true;
      const old = btn.textContent;
      btn.textContent = 'Recherche des saisons…';
      try {
        await fetch('/api/mapping/season-auto-match-series', {
          method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({plex_rating_key:btn.dataset.key})
        });
        const toggle = [...tbody.querySelectorAll('.season-toggle')].find(x => x.dataset.key === btn.dataset.key);
        if (toggle) {
          if (toggle.getAttribute('aria-expanded') !== 'true') await toggleSeasons(toggle);
          else {
            const holder = toggle.closest('tr').nextElementSibling;
            if (holder) await refreshOpenSeasons(holder, btn.dataset.key);
          }
        }
      } finally { btn.disabled = false; btn.textContent = old; }
    }));

    tbody.querySelectorAll('.toggle-ignore').forEach(btn => btn.addEventListener('click', async () => {
      await fetch('/api/mapping/ignore', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({titre_plex:btn.dataset.titre})
      });
      await load();
    }));

    tbody.querySelectorAll('.delete-mapping').forEach(btn => btn.addEventListener('click', async () => {
      const confirmed = await askConfirmation({
        title: 'Supprimer le mapping',
        message: `Supprimer « ${btn.dataset.titre} » et toutes ses liaisons de saisons ? Cette action est définitive.`,
        confirmLabel: 'Supprimer',
        danger: true
      });
      if (!confirmed) return;

      btn.disabled = true;
      try {
        const response = await fetch('/api/mapping/delete', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body:JSON.stringify({titre_plex:btn.dataset.titre})
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok || !data.ok) throw new Error(data.error || `Erreur HTTP ${response.status}`);
        await load();
      } catch (err) {
        console.error(err);
        btn.disabled = false;
        await askConfirmation({
          title: 'Suppression impossible',
          message: `Impossible de supprimer ce mapping : ${err.message}`,
          confirmLabel: 'Fermer'
        });
      }
    }));
    syncSelectAll();
  }

  async function toggleSeasons(btn) {
    const row = btn.closest('tr');
    const existing = row.nextElementSibling;
    if (existing && existing.classList.contains('seasons-row')) {
      existing.remove(); btn.setAttribute('aria-expanded','false'); btn.textContent='›'; return;
    }
    btn.setAttribute('aria-expanded','true'); btn.textContent='⌄';
    const holder = document.createElement('tr'); holder.className='seasons-row';
    holder.innerHTML = '<td></td><td colspan="4"><div class="seasons-loading muted">Chargement des saisons…</div></td></tr>';
    row.after(holder);
    await refreshOpenSeasons(holder, btn.dataset.key);
  }

  async function refreshOpenSeasons(holder, ratingKey) {
    try {
      const r = await fetch('/api/mapping/seasons?plex_rating_key=' + encodeURIComponent(ratingKey));
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Erreur');
      holder.querySelector('td[colspan="4"]').innerHTML = `<div class="season-list">${(d.rows||[]).map(seasonHtml).join('') || '<span class="muted">Aucune saison détectée.</span>'}</div>`;
      bindSeasonActions(holder);
    } catch (e) {
      holder.querySelector('td[colspan="4"]').innerHTML='<span class="test-fail">Impossible de charger les saisons.</span>';
    }
  }

  function seasonHtml(s) {
    const hasLink = !!s.anilist_id;
    return `<div class="season-item ${hasLink ? 'is-linked' : 'is-unlinked'}">
      <div class="season-info">
        <div class="season-art">${s.plex_thumb_url ? `<img src="${esc(s.plex_thumb_url)}" class="season-cover" alt="Affiche Plex">` : '<div class="season-cover-placeholder">P</div>'}</div>
        <span class="season-number">S${esc(s.plex_season_index)}</span>
        <div><strong>${esc(s.titre_saison || `Saison ${s.plex_season_index}`)}</strong><div class="muted small">${esc(s.episodes || 0)} épisode(s)</div>${s.season_offset != null ? (() => { const n=Number(s.season_offset); const sign=n>=0?'+':''; return `<div class="conversion-preview"><span class="conversion-label">Décalage</span><code>${sign}${esc(n)}</code><span class="muted small">${n<0 ? `Plex E${1-n} → AniList E1` : `Plex E1 → AniList E${1+n}`}</span></div>`; })() : '<div class="muted small conversion-preview">Aucun décalage</div>'}</div>
      </div>
      <div class="season-target"><div class="season-anilist-art">${s.image_anilist ? `<img src="${esc(s.image_anilist)}" class="season-cover" alt="Affiche AniList">` : '<div class="season-cover-placeholder anilist-placeholder">A</div>'}<span class="art-label">AniList</span></div><div><div class="mapping-title">${esc(s.titre_anilist || 'Non liée')}</div><span class="status-pill ${esc(s.statut)}">${esc(STATUT_LABELS[s.statut] || s.statut)}</span><div class="season-links">${s.plex_link ? `<a href="${esc(s.plex_link)}" target="_blank" rel="noopener" class="link-btn">Plex</a>` : ''}${s.tvdb_series_link ? `<a href="${esc(s.tvdb_series_link)}" target="_blank" rel="noopener" class="link-btn">TheTVDB</a>` : ''}${s.tvdb_season_link ? `<a href="${esc(s.tvdb_season_link)}" target="_blank" rel="noopener" class="link-btn">Saison TVDB</a>` : ''}${s.anilist_link ? `<a href="${esc(s.anilist_link)}" target="_blank" rel="noopener" class="link-btn">AniList</a>` : ''}</div></div></div>
      <div class="season-actions"><button class="btn-primary season-auto" data-key="${esc(s.plex_rating_key)}" data-season="${esc(s.plex_season_index)}">${hasLink ? 'Rechercher à nouveau' : 'Auto-lier'}</button><button class="btn-secondary season-reassign" data-key="${esc(s.plex_rating_key)}" data-season="${esc(s.plex_season_index)}">Rechercher / choisir</button><button class="btn-secondary season-rules" data-key="${esc(s.plex_rating_key)}" data-season="${esc(s.plex_season_index)}">Décalage des épisodes</button></div>
    </div>`;
  }

  function bindSeasonActions(holder) {
    holder.querySelectorAll('.season-auto').forEach(btn => btn.addEventListener('click', async () => {
      btn.disabled=true; const old=btn.textContent; btn.textContent='Recherche…';
      try {
        await fetch('/api/mapping/season-auto-match',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({plex_rating_key:btn.dataset.key,season_index:Number(btn.dataset.season)})});
        await refreshOpenSeasons(holder, btn.dataset.key);
      } finally { btn.disabled=false; }
    }));
    holder.querySelectorAll('.season-reassign').forEach(btn => btn.addEventListener('click', () => openSearch({type:'season', plex_rating_key:btn.dataset.key, season_index:Number(btn.dataset.season)})));
    holder.querySelectorAll('.season-rules').forEach(btn => btn.addEventListener('click', () => openRules({plex_rating_key:btn.dataset.key, season_index:Number(btn.dataset.season)}, holder)));
  }

  document.getElementById('assign-accounts-selected').addEventListener('click', async () => {
    const rows = selectedRows();
    if (!rows.length) { alert('Sélectionne au moins une série.'); return; }
    openAccountsModal(rows.map(r => r.plex_rating_key));
  });

  accountsModalSelect.addEventListener('change', () => {
    const id = Number(accountsModalSelect.value);
    if (!id) return;
    accountsModalSelected = [...new Set([...accountsModalSelected, id])];
    renderAccountsModal();
  });
  accountsModalCancel.addEventListener('click', closeAccountsModal);
  accountsModalClose.addEventListener('click', closeAccountsModal);
  accountsModal.addEventListener('click', e => { if (e.target === accountsModal) closeAccountsModal(); });
  accountsModalSave.addEventListener('click', async () => {
    if (!accountsModalKeys.length) return;
    accountsModalSave.disabled = true;
    try {
      const r = await fetch('/api/mapping/series-accounts', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({plex_rating_keys:accountsModalKeys,account_ids:accountsModalSelected})});
      const d = await r.json().catch(()=>({}));
      if (!r.ok || !d.ok) throw new Error(d.error || 'Affectation impossible');
      closeAccountsModal();
      await load();
    } catch(e) { alert(e.message); } finally { accountsModalSave.disabled = false; }
  });

  document.getElementById('select-all').addEventListener('change', e => {
    tbody.querySelectorAll('.mapping-select').forEach(cb => {
      cb.checked = e.target.checked;
    });
    syncSelectAll();
  });

  document.getElementById('auto-filtered').addEventListener('click', async () => {
    // Si l'utilisateur a coché des séries, le bouton ne traite QUE cette sélection.
    // Sinon, il traite toutes les séries correspondant aux filtres actifs.
    const selected = selectedRows();
    const sourceRows = selected.length ? selected : filteredRows();
    const rows = sourceRows.filter(r => r.statut !== 'ignore').filter(r => r.plex_rating_key);

    if (!rows.length) {
      await askConfirmation({
        title: selected.length ? 'Aucune série sélectionnée à mapper' : 'Aucune série à mapper',
        message: selected.length
          ? 'Les séries sélectionnées sont ignorées ou ne disposent pas d’une clé Plex exploitable.'
          : 'Aucune série ne correspond aux filtres actuels et n’est disponible pour le mapping.',
        confirmLabel: 'Fermer'
      });
      return;
    }

    const usingSelection = selected.length > 0;
    const confirmed = await askConfirmation({
      title: 'Lancer la recherche groupée',
      message: usingSelection
        ? `Rechercher les saisons non liées des ${rows.length} série(s) sélectionnée(s) ? Les saisons déjà liées seront ignorées.`
        : `Aucune sélection active : rechercher les saisons non liées des ${rows.length} série(s) correspondant aux filtres ? Les saisons déjà liées seront ignorées.`,
      confirmLabel: 'Lancer le mapping'
    });
    if (!confirmed) return;

    const b = document.getElementById('auto-filtered');
    b.disabled = true;
    const old = b.textContent;
    b.textContent = 'Recherche des saisons non liées…';
    try {
      let checkedTotal = 0;
      let matchedTotal = 0;
      let skippedLinkedTotal = 0;
      let errorTotal = 0;
      for (const row of rows) {
        const response = await fetch('/api/mapping/season-auto-match-series', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({plex_rating_key:row.plex_rating_key})
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok || !data.ok) {
          errorTotal++;
          console.error(`Mapping impossible pour ${row.titre_plex}:`, data.error || response.status);
          continue;
        }
        checkedTotal += Number(data.checked || 0);
        matchedTotal += Number(data.matched || 0);
        skippedLinkedTotal += Number(data.skipped_linked || 0);
      }
      await load();
      const parts = [`${checkedTotal} saison(s) recherchée(s)`, `${skippedLinkedTotal} déjà liée(s) ignorée(s)`];
      if (matchedTotal) parts.push(`${matchedTotal} correspondance(s) trouvée(s)`);
      if (errorTotal) parts.push(`${errorTotal} série(s) en erreur`);
      scanStatus.textContent = parts.join(' · ');
    } finally {
      b.disabled = false;
      b.textContent = old;
    }
  });

  document.getElementById('delete-selected').addEventListener('click', async () => {
    const rows = selectedRows();
    if (!rows.length) {
      await askConfirmation({
        title: 'Aucune sélection',
        message: 'Cochez au moins une série avant de lancer la suppression.',
        confirmLabel: 'Fermer'
      });
      return;
    }

    const confirmed = await askConfirmation({
      title: 'Supprimer la sélection',
      message: `Supprimer ${rows.length} série(s) sélectionnée(s) et toutes leurs liaisons de saisons ? Cette action est définitive.`,
      confirmLabel: 'Supprimer',
      danger: true
    });
    if (!confirmed) return;

    const button = document.getElementById('delete-selected');
    button.disabled = true;
    try {
      const response = await fetch('/api/mapping/delete-bulk', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({plex_rating_keys:rows.map(r => r.plex_rating_key)})
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.ok) throw new Error(data.error || `Erreur HTTP ${response.status}`);
      await load();
    } catch (err) {
      console.error(err);
      await askConfirmation({
        title: 'Suppression impossible',
        message: `Impossible de supprimer la sélection : ${err.message}`,
        confirmLabel: 'Fermer'
      });
    } finally {
      button.disabled = false;
    }
  });


  let currentRuleTarget = null;

  async function loadOffsetAndConversion() {
    if (!currentRuleTarget) return;
    const params = new URLSearchParams({plex_rating_key: currentRuleTarget.plex_rating_key, season_index: String(currentRuleTarget.season_index)});
    seasonOffsetResult.textContent = '';
    try {
      const r = await fetch('/api/mapping/conversion?' + params.toString());
      const d = await r.json().catch(() => ({}));
      if (!r.ok || !d.ok) throw new Error(d.error || 'Impossible de charger le décalage');
      const offset = d.season_offset;
      seasonOffsetInput.value = offset == null ? '' : String(offset);
      seasonOffsetDelete.disabled = offset == null;
      if (offset == null) {
        seasonOffsetCurrent.innerHTML = '<strong>Aucun décalage enregistré</strong><span class="muted small">Plex E1 → AniList E1</span>';
      } else {
        const n = Number(offset);
        const sign = n >= 0 ? '+' : '';
        const firstPlex = n < 0 ? 1 - n : 1;
        seasonOffsetCurrent.innerHTML = n < 0
          ? `<strong>Décalage actuel : ${sign}${esc(n)}</strong><span class="muted small">Plex E${firstPlex} → AniList E1</span>`
          : `<strong>Décalage actuel : ${sign}${esc(n)}</strong><span class="muted small">Plex E1 → AniList E${1 + n}</span>`;
      }
      updateOffsetPreview();
    } catch (e) {
      seasonOffsetCurrent.innerHTML = `<strong>Erreur</strong><span class="muted small">${esc(e.message)}</span>`;
    }
  }

  function updateOffsetPreview() {
    const raw = seasonOffsetInput.value.trim();
    if (!raw) {
      seasonOffsetPreview.textContent = 'Exemple : avec +12, Plex E1 devient AniList E13.';
      return;
    }
    const n = Number(raw);
    if (!Number.isInteger(n)) {
      seasonOffsetPreview.textContent = 'Le décalage doit être un nombre entier.';
      return;
    }
    const e1 = 1 + n;
    const e2 = 2 + n;
    const e10 = 10 + n;
    const fmt = value => value > 0 ? `AniList E${value}` : 'non résolu';
    const sign = n >= 0 ? '+' : '';
    seasonOffsetPreview.innerHTML = `<strong>Prévisualisation :</strong> Plex E1 → ${fmt(e1)} · Plex E2 → ${fmt(e2)} · Plex E10 → ${fmt(e10)}<span class="muted small"> (décalage ${sign}${n})</span>`;
    if (e1 <= 0) {
      seasonOffsetPreview.innerHTML += '<br><span class="muted small">C’est autorisé : cela signifie que Plex commence après E1. Le premier épisode Plex correspondant à AniList E1 sera le premier épisode avec une cible positive.</span>';
    }
  }

  async function saveSeasonOffset() {
    if (!currentRuleTarget) return;
    const raw = seasonOffsetInput.value.trim();
    if (!raw || !/^[+-]?\d+$/.test(raw)) {
      seasonOffsetResult.textContent = 'Entre un entier, par exemple +12, 0 ou -3.';
      return;
    }
    const offset = Number(raw);
    if (!Number.isSafeInteger(offset)) {
      seasonOffsetResult.textContent = 'Le décalage est trop grand.';
      return;
    }
    seasonOffsetSave.disabled = true;
    try {
      const r = await fetch('/api/mapping/season-offset', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({plex_rating_key:currentRuleTarget.plex_rating_key, season_index:currentRuleTarget.season_index, offset})});
      const d = await r.json().catch(() => ({}));
      if (!r.ok || !d.ok) throw new Error(d.error || 'Impossible d’enregistrer le décalage');
      seasonOffsetResult.textContent = `Décalage ${offset >= 0 ? '+' : ''}${offset} enregistré.`;
      await loadOffsetAndConversion();
      // Fermer la fenêtre après un enregistrement réussi.
      rulesModal.classList.add('hidden');
      await refreshRuleParent();
    } catch (e) { seasonOffsetResult.textContent = e.message; }
    finally { seasonOffsetSave.disabled = false; }
  }

  async function deleteSeasonOffset() {
    if (!currentRuleTarget || seasonOffsetDelete.disabled) return;
    const ok = await askConfirmation({title:'Supprimer le décalage ?', message:'La saison reviendra à sa conversion automatique. Aucun épisode Plex ne sera supprimé.', confirmLabel:'Supprimer', danger:true});
    if (!ok) return;
    const r = await fetch('/api/mapping/season-offset', {method:'DELETE', headers:{'Content-Type':'application/json'}, body:JSON.stringify({plex_rating_key:currentRuleTarget.plex_rating_key, season_index:currentRuleTarget.season_index})});
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.ok) { seasonOffsetResult.textContent = d.error || 'Suppression impossible'; return; }
    seasonOffsetResult.textContent = 'Décalage supprimé. La conversion automatique reprend.';
    await loadOffsetAndConversion();
    await refreshRuleParent();
  }

  async function refreshRuleParent() {
    if (!currentRuleParent || !currentRuleTarget) return;
    await refreshOpenSeasons(currentRuleParent, currentRuleTarget.plex_rating_key);
  }

  async function openRules(target, parent) {
    currentRuleTarget = target;
    currentRuleParent = parent || null;
    rulesContext.textContent = `Saison ${target.season_index} — indique seulement de combien la numérotation Plex doit être décalée vers AniList.`;
    seasonOffsetInput.value = '';
    seasonOffsetResult.textContent = '';
    rulesModal.classList.remove('hidden');
    await loadOffsetAndConversion();
  }

  seasonOffsetInput.addEventListener('input', updateOffsetPreview);
  seasonOffsetSave.addEventListener('click', saveSeasonOffset);
  seasonOffsetDelete.addEventListener('click', deleteSeasonOffset);
  document.getElementById('rules-close').addEventListener('click', () => { rulesModal.classList.add('hidden'); });
  rulesModal.addEventListener('click', e => { if (e.target === rulesModal) rulesModal.classList.add('hidden'); });

  function openSearch(target) {
    currentTarget=target;
    input.value='';
    idInput.value='';
    idResult.textContent='';
    results.innerHTML='';
    modal.classList.remove('hidden');
    if (target.type !== 'season') return;
    input.placeholder=`Titre de la série ou synonyme — Saison ${target.season_index}`;
    modalTitle.textContent=`Lier la saison ${target.season_index}`;
    searchSeasonContext(target);
    input.focus();
  }

  async function searchSeasonContext(target) {
    results.innerHTML='<div class="search-loading"><span class="spinner"></span><div><strong>Recherche intelligente</strong><small>Titres, romaji, titres natifs et synonymes AniList</small></div></div>';
    const params = new URLSearchParams({plex_rating_key:target.plex_rating_key, season_index:String(target.season_index)});
    const q=input.value.trim(); if(q) params.set('q',q);
    const r=await fetch('/api/anilist/search-season?'+params.toString()); const d=await r.json();
    if(!r.ok){ results.innerHTML=`<div class="search-error">${esc(d.error||'Recherche impossible')}</div>`; return; }
    renderSearchResults(d.results||[]);
  }

  function renderSearchResults(items){
    results.innerHTML=(items||[]).map(x=>`<button class="result-card ${x.match_reason?'is-ranked':''}" data-id="${esc(x.id)}" data-title="${esc(x.title)}" data-image="${esc(x.image||'')}">
      ${x.image?`<img src="${esc(x.image)}" alt="">`:'<div class="result-placeholder">?</div>'}
      <span class="result-copy"><strong>${esc(x.title)}</strong><small>${esc([x.title_romaji,x.title_english,x.title_native].filter(Boolean).join(' · '))}</small>${(x.synonyms||[]).length?`<small class="result-synonyms">Synonymes : ${esc(x.synonyms.slice(0,6).join(' · '))}</small>`:''}${x.match_reason?`<em>${esc(x.match_reason)}</em>`:''}</span>
    </button>`).join('') || '<div class="muted search-empty">Aucun résultat. Essayez un autre titre ou un synonyme.</div>';
    results.querySelectorAll('.result-card').forEach(c=>c.addEventListener('click',async()=>{
      const payload={anilist_id:Number(c.dataset.id),titre_anilist:c.dataset.title,image_anilist:c.dataset.image,plex_rating_key:currentTarget.plex_rating_key,season_index:currentTarget.season_index};
      await fetch('/api/mapping/season-reassign',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      const key=currentTarget.plex_rating_key;
      idInput.value='';
      idResult.textContent='';
      input.value='';
      modal.classList.add('hidden'); await load();
      const toggle=[...tbody.querySelectorAll('.season-toggle')].find(x => x.dataset.key === key);
      if(toggle) { toggle.setAttribute('aria-expanded','true'); toggle.textContent='⌄'; const holder=toggle.closest('tr').nextElementSibling || document.createElement('tr'); if(!holder.parentNode){ holder.className='seasons-row'; holder.innerHTML='<td></td><td colspan="4"></td>'; toggle.closest('tr').after(holder); } await refreshOpenSeasons(holder,key); }
    }));
  }

  async function applyAniListId(){
    if(!currentTarget || currentTarget.type!=='season') return;
    const raw=idInput.value.trim();
    if(!raw){ idResult.textContent='Entrez un ID ou une URL AniList.'; return; }
    idApply.disabled=true; idResult.textContent='Vérification…';
    try {
      const r=await fetch('/api/anilist/by-id?id='+encodeURIComponent(raw));
      const d=await r.json().catch(()=>({}));
      if(!r.ok || !d.ok) throw new Error(d.error||'Anime AniList introuvable');
      const x=d.result;
      const payload={anilist_id:Number(x.id),titre_anilist:x.title,image_anilist:x.image||'',plex_rating_key:currentTarget.plex_rating_key,season_index:currentTarget.season_index};
      const rr=await fetch('/api/mapping/season-reassign',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      const dd=await rr.json().catch(()=>({}));
      if(!rr.ok || !dd.ok) throw new Error(dd.error||'Impossible d’enregistrer le mapping');
      const key=currentTarget.plex_rating_key;
      idInput.value='';
      idResult.textContent='';
      input.value='';
      modal.classList.add('hidden'); await load();
      const toggle=[...tbody.querySelectorAll('.season-toggle')].find(x => x.dataset.key === key);
      if(toggle) { toggle.setAttribute('aria-expanded','true'); toggle.textContent='⌄'; const holder=toggle.closest('tr').nextElementSibling || document.createElement('tr'); if(!holder.parentNode){ holder.className='seasons-row'; holder.innerHTML='<td></td><td colspan="4"></td>'; toggle.closest('tr').after(holder); } await refreshOpenSeasons(holder,key); }
    } catch(err) { idResult.textContent=err.message; }
    finally { idApply.disabled=false; }
  }
  idApply.addEventListener('click',applyAniListId);
  idInput.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();applyAniListId();}});

  async function search(){ if(!currentTarget || currentTarget.type!=='season') return; await searchSeasonContext(currentTarget); }
  input.addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(search,300);});
  cancel.addEventListener('click',()=>modal.classList.add('hidden'));
  modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.add('hidden')});

  scanBtn.addEventListener('click', async () => {
    scanBtn.disabled=true; scanStatus.textContent='Démarrage…'; progressWrap.classList.remove('hidden');
    const r=await fetch('/api/mapping/scan',{method:'POST'}); const d=await r.json(); if(!d.ok){scanStatus.textContent=d.error||'Erreur';scanBtn.disabled=false;return;}
    pollTimer=setInterval(async()=>{const sr=await fetch('/api/mapping/scan/status');const st=await sr.json();const pct=st.total?Math.round(st.done/st.total*100):0;progressFill.style.width=pct+'%';scanStatus.textContent=st.running?`${st.done}/${st.total} — ${st.current||''}`:`Terminé : ${st.done} série(s)${st.deleted ? ` · ${st.deleted} supprimée(s)` : ''}`;if(!st.running){clearInterval(pollTimer);scanBtn.disabled=false;await load();}},700);
  });

  await load();
})();

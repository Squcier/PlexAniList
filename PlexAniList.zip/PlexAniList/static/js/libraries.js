/* Libraries : récupère les bibliothèques Plex et permet d'activer/désactiver. */
(async function () {
  const tbody = document.querySelector('#libs-table tbody');
  const errBox = document.getElementById('libs-error');

  async function load() {
    try {
      const r = await fetch('/api/libraries');
      const data = await r.json();
      if (data.error) {
        errBox.textContent = "Plex injoignable : " + data.error;
        errBox.classList.remove('hidden');
      } else errBox.classList.add('hidden');
      render(data.libraries || []);
    } catch (e) {
      errBox.textContent = "Erreur : " + e;
      errBox.classList.remove('hidden');
    }
  }

  function render(rows) {
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="3" class="muted">Aucune bibliothèque détectée.</td></tr>';
      return;
    }
    tbody.innerHTML = rows.map(r => `
      <tr>
        <td>${escape(r.nom)}</td>
        <td><code>${escape(r.id_plex)}</code></td>
        <td>
          <label class="switch">
            <input type="checkbox" data-id="${escape(r.id_plex)}" ${r.activee ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </td>
      </tr>`).join('');

    tbody.querySelectorAll('input[type=checkbox]').forEach(cb => {
      cb.addEventListener('change', async () => {
        await fetch('/api/libraries/toggle', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id_plex: cb.dataset.id, activee: cb.checked })
        });
      });
    });
  }

  function escape(s) { return String(s == null ? '' : s).replace(/[<>"&]/g, c => ({'<':'&lt;','>':'&gt;','"':'&quot;','&':'&amp;'}[c])); }

  load();
})();

/* Paramètres : chargement/sauvegarde, tests Plex/AniList et sauvegarde complète. */
(async function () {
  const form = document.getElementById('settings-form');
  const status = document.getElementById('settings-status');
  const testPlexBtn = document.getElementById('test-plex');
  const testPlexResult = document.getElementById('test-plex-result');
  const testAnilistBtn = document.getElementById('test-anilist');
  const testAnilistResult = document.getElementById('test-anilist-result');
  const exportBtn = document.getElementById('export-backup');
  const importInput = document.getElementById('import-backup-file');
  const backupStatus = document.getElementById('backup-status');

  const TEXT_KEYS = ['plex_url', 'plex_token', 'anilist_token', 'progress_threshold', 'poll_interval', 'auto_scan_interval_hours', 'auto_link_interval_hours'];
  const BOOL_KEYS = ['sync_on_pause', 'auto_complete', 'auto_scan_enabled', 'auto_link_enabled'];

  function escape(s) { return String(s == null ? '' : s); }

  async function load() {
    const r = await fetch('/api/settings');
    const data = await r.json();
    for (const k of TEXT_KEYS) {
      const el = form.elements[k];
      if (el) el.value = escape(data[k]);
    }
    for (const k of BOOL_KEYS) {
      const el = form.elements[k];
      if (el) el.checked = !!data[k];
    }
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = {};
    for (const k of TEXT_KEYS) body[k] = form.elements[k].value;
    for (const k of BOOL_KEYS) body[k] = form.elements[k].checked;

    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await r.json();
    if (data.ok) {
      status.textContent = 'Enregistré ✓';
      setTimeout(() => status.textContent = '', 2500);
    } else {
      status.textContent = data.error || 'Erreur';
    }
  });

  async function testConnection(btn, resultEl, url, payload) {
    btn.disabled = true;
    resultEl.textContent = 'Test en cours…';
    resultEl.className = 'muted';
    try {
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await r.json();
      if (data.ok) {
        resultEl.textContent = data.message || 'OK ✓';
        resultEl.className = 'test-ok';
      } else {
        resultEl.textContent = data.error || 'Échec';
        resultEl.className = 'test-fail';
      }
    } catch (err) {
      resultEl.textContent = 'Erreur réseau';
      resultEl.className = 'test-fail';
    } finally {
      btn.disabled = false;
    }
  }

  testPlexBtn.addEventListener('click', () => testConnection(
    testPlexBtn, testPlexResult, '/api/settings/test-plex',
    { plex_url: form.elements.plex_url.value, plex_token: form.elements.plex_token.value }
  ));

  testAnilistBtn.addEventListener('click', () => testConnection(
    testAnilistBtn, testAnilistResult, '/api/settings/test-anilist',
    { anilist_token: form.elements.anilist_token.value }
  ));

  exportBtn.addEventListener('click', () => {
    backupStatus.textContent = 'Préparation de la sauvegarde…';
    window.location.href = '/api/backup/export';
    setTimeout(() => backupStatus.textContent = 'Export terminé ✓', 700);
  });

  importInput.addEventListener('change', async () => {
    const file = importInput.files && importInput.files[0];
    if (!file) return;
    backupStatus.textContent = 'Import en cours…';
    const formData = new FormData();
    formData.append('file', file);
    try {
      const r = await fetch('/api/backup/import', { method: 'POST', body: formData });
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || 'Import impossible');
      const c = data.counts || {};
      backupStatus.textContent = `Import terminé ✓ — ${c.mappings || 0} séries, ${c.seasons || 0} saisons, ${c.libraries || 0} bibliothèques`;
      await load();
    } catch (err) {
      backupStatus.textContent = err.message || 'Import impossible';
      backupStatus.className = 'test-fail';
    } finally {
      importInput.value = '';
    }
  });


  async function loadAccounts() {
    const r = await fetch('/api/anilist/accounts');
    const d = await r.json();
    const holder = document.getElementById('anilist-accounts');
    const accounts = d.accounts || [];
    holder.innerHTML = accounts.map((a, index) => `
      <div class="account-row ${index === 0 ? 'account-row-primary' : ''}" data-id="${a.id}">
        <div class="account-main"><strong>${escape(a.nom)} ${index === 0 ? '<span class="account-primary-badge">Principal</span>' : ''}</strong><span class="muted">${a.token_configured ? 'Token configuré' : 'Sans token'}</span></div>
        ${index === 0 ? '<span class="account-default-note">Toujours actif · cible par défaut</span>' : `<label class="checkbox-row"><input class="account-active" type="checkbox" ${a.actif ? 'checked' : ''}> Actif</label>`}
        <button type="button" class="btn-secondary account-test">Tester</button>
        ${index === 0 ? '' : '<button type="button" class="btn-secondary danger account-delete">Supprimer</button>'}
      </div>`).join('') || '<div class="muted">Aucun compte nommé. Le token historique reste disponible pour compatibilité.</div>';

    holder.querySelectorAll('.account-active').forEach(el => el.addEventListener('change', async e => {
      const id = e.target.closest('.account-row').dataset.id;
      await fetch('/api/anilist/accounts/' + id, {method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify({actif:e.target.checked})});
    }));
    holder.querySelectorAll('.account-test').forEach(btn => btn.addEventListener('click', async e => {
      const id = e.target.closest('.account-row').dataset.id;
      btn.disabled = true; btn.textContent = 'Test…';
      try {
        const r = await fetch('/api/anilist/accounts/' + id + '/test', {method:'POST'});
        const d = await r.json();
        document.getElementById('anilist-accounts-status').textContent = d.ok ? d.message : (d.error || 'Échec');
      } finally { btn.disabled = false; btn.textContent = 'Tester'; }
    }));
    holder.querySelectorAll('.account-delete').forEach(btn => btn.addEventListener('click', async e => {
      const row = e.target.closest('.account-row');
      if (!confirm('Supprimer ce compte AniList ? Les séries ne seront pas supprimées, mais elles ne seront plus synchronisées vers ce compte.')) return;
      await fetch('/api/anilist/accounts/' + row.dataset.id, {method:'DELETE'});
      await loadAccounts();
    }));
  }

  document.getElementById('anilist-account-add').addEventListener('click', async () => {
    const name = document.getElementById('anilist-account-name').value.trim();
    const token = document.getElementById('anilist-account-token').value.trim();
    const result = document.getElementById('anilist-accounts-status');
    if (!name || !token) { result.textContent = 'Nom et token obligatoires.'; return; }
    const r = await fetch('/api/anilist/accounts', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({nom:name, token})});
    const d = await r.json();
    if (!r.ok || !d.ok) { result.textContent = d.error || 'Ajout impossible'; return; }
    document.getElementById('anilist-account-name').value = '';
    document.getElementById('anilist-account-token').value = '';
    result.textContent = 'Compte ajouté ✓';
    await loadAccounts();
  });

  await loadAccounts();
  load();
})();

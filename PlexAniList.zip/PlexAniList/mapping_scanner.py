"""
Scanner de mapping Plex <-> AniList.

Parcourt toutes les bibliothèques Plex de type "show" (actives), récupère la
liste complète des séries, et tente de faire correspondre chaque titre à une
entrée AniList via l'API de recherche. Tourne dans un thread de fond pour ne
pas bloquer les requêtes HTTP, avec un état de progression consultable.
"""

import re
import threading
import time

from models import db, Library, Mapping, SeasonMapping, Setting
import plex_client
import anilist_client


# Délai entre deux appels à l'API AniList (anonyme) pour rester sous la limite de débit.
ANILIST_THROTTLE_SECONDS = 0.7


def _normalize(title):
    """Normalise un titre, accents compris, pour comparer aussi les synonymes français."""
    if not title:
        return ""
    import unicodedata
    t = unicodedata.normalize("NFKD", str(title).lower())
    t = "".join(c for c in t if not unicodedata.combining(c))
    t = re.sub(r"\(.*?\)", " ", t)
    t = re.sub(r"[^a-z0-9]+", " ", t)
    return t.strip()


def _candidate_titles(item):
    titles = [item.get("title_english"), item.get("title_romaji"), item.get("title_native")]
    titles += list(item.get("synonyms") or [])
    return [x for x in titles if x]


def _best_match(titre_plex, token):
    """Recherche large puis privilégie une correspondance via les synonymes AniList."""
    queries = [titre_plex]
    # Une seconde requête avec le titre nettoyé aide lorsque Plex contient des
    # tags comme [Dub], (TV), etc. ; le scoring final se fait aussi sur synonyms.
    cleaned = re.sub(r"[\[\]{}]", " ", titre_plex)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    if cleaned and cleaned.lower() != titre_plex.lower():
        queries.append(cleaned)

    all_results = []
    seen = set()
    for query in queries:
        for result in anilist_client.search_media(query, token=token or None):
            rid = result.get("id")
            if rid not in seen:
                seen.add(rid)
                all_results.append(result)
        if all_results and len(all_results) >= 10:
            break

    if not all_results:
        return None, False

    target = _normalize(titre_plex)
    # 1. égalité exacte, titres officiels OU synonymes
    for r in all_results:
        for c in _candidate_titles(r):
            if _normalize(c) == target:
                return r, True

    # 2. inclusion prudente pour les titres Plex enrichis
    scored = []
    for r in all_results:
        score = 0
        for c in _candidate_titles(r):
            n = _normalize(c)
            if n and (n in target or target in n):
                score = max(score, 80 if n in target else 70)
        scored.append((score, r))
    scored.sort(key=lambda x: x[0], reverse=True)
    return (scored[0][1] if scored and scored[0][0] else all_results[0]), False


def _best_season_match(series_title, season_index, season_title, token):
    """Match saison robuste : saison 1 sans suffixe + synonymes + relations."""
    results = anilist_client.search_season_media(
        series_title, season_index, season_title, token=token or None
    )
    if not results:
        return None, False

    target = _normalize(series_title)
    season_norm = _normalize(season_title or "")
    ranked = []
    for r in results:
        names = [_normalize(x) for x in _candidate_titles(r)]
        score = 0
        if target and target in names:
            score += 90 if season_index == 1 else 55
        elif target and any(target in n or n in target for n in names):
            score += 68
        if season_norm and season_norm in names:
            score += 20
        text = " ".join(names)
        if f"season {season_index}" in text or f"saison {season_index}" in text or f" {season_index}" in text:
            score += 18
        rel = str(r.get("relation_type") or "")
        if rel == "SEQUEL" and season_index > 1:
            score += 15
        ranked.append((score, r))
    ranked.sort(key=lambda x: x[0], reverse=True)
    return (ranked[0][1], ranked[0][0] >= 75) if ranked else (None, False)


class MappingScanner:
    """Scan synchrone lancé dans un thread ; expose un état de progression."""

    def __init__(self, app):
        self.app = app
        self._lock = threading.Lock()
        self._thread = None
        self.state = {
            "running": False,
            "total": 0,
            "done": 0,
            "current": "",
            "created": 0,
            "updated": 0,
            "skipped_manuel": 0,
            "deleted": 0,
            "error": None,
            "started_at": None,
            "finished_at": None,
        }

    def status(self):
        with self._lock:
            return dict(self.state)

    def start(self):
        with self._lock:
            if self.state["running"]:
                return False
            self.state.update({
                "running": True, "total": 0, "done": 0, "current": "",
                "created": 0, "updated": 0, "skipped_manuel": 0, "deleted": 0,
                "error": None, "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "finished_at": None,
            })
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return True

    def _set(self, **kwargs):
        with self._lock:
            self.state.update(kwargs)

    def _run(self):
        try:
            with self.app.app_context():
                self._scan()
        except Exception as e:
            self._set(error=f"{type(e).__name__}: {e}")
        finally:
            self._set(running=False, finished_at=time.strftime("%Y-%m-%d %H:%M:%S"))

    def _scan(self):
        plex_url = Setting.get("plex_url", "")
        plex_token = Setting.get("plex_token", "")
        anilist_token = Setting.get("anilist_token", "")

        if not plex_token:
            raise plex_client.PlexError("Aucun token Plex configuré")

        # Rafraîchit la liste des bibliothèques + leur type avant de filtrer.
        remote_libs = plex_client.list_libraries(plex_url, plex_token)
        for r in remote_libs:
            lib = Library.query.filter_by(id_plex=r["id_plex"]).first()
            if not lib:
                lib = Library(id_plex=r["id_plex"], nom=r["nom"], activee=True, type=r.get("type"))
                db.session.add(lib)
            else:
                lib.nom = r["nom"]
                lib.type = r.get("type")
        db.session.commit()

        # Cache l'identifiant machine pour construire les liens "Voir sur Plex".
        try:
            machine_id = plex_client.get_machine_identifier(plex_url, plex_token)
            Setting.set("plex_machine_id", machine_id)
        except plex_client.PlexError:
            pass  # pas bloquant : les liens Plex seront simplement absents

        libs = Library.query.filter_by(activee=True, type="show").all()

        # Rassemble toutes les séries de toutes les bibliothèques actives.
        # On ne supprime les anciens mappings qu'après avoir obtenu une réponse
        # complète de Plex pour la bibliothèque concernée : une erreur réseau ne
        # doit jamais être interprétée comme « toutes les séries ont disparu ».
        toutes_series = []
        successful_library_ids = set()
        failed_library_ids = set()
        seen_rating_keys = set()
        for lib in libs:
            try:
                series = plex_client.list_series(plex_url, plex_token, lib.id_plex)
                successful_library_ids.add(lib.id_plex)
            except plex_client.PlexError as e:
                failed_library_ids.add(lib.id_plex)
                self._set(error=f"Bibliothèque '{lib.nom}': {e}")
                continue
            for s in series:
                s["library_id_plex"] = lib.id_plex
                seen_rating_keys.add(str(s.get("rating_key")))
                toutes_series.append(s)

        self._set(total=len(toutes_series))

        for s in toutes_series:
            self._set(current=s["titre"])
            existing = Mapping.query.filter_by(titre_plex=s["titre"]).first()

            if existing and existing.statut == "manuel":
                # On respecte le choix de l'utilisateur : on rafraîchit juste les
                # métadonnées Plex (miniature/année/rating key) sans toucher au lien AniList.
                existing.plex_rating_key = s["rating_key"]
                existing.plex_thumb = s.get("thumb")
                existing.plex_year = s.get("annee")
                existing.tvdb_id = s.get("tvdb_id")
                existing.library_id_plex = s["library_id_plex"]
                db.session.commit()
                try:
                    for season in plex_client.list_seasons(plex_url, plex_token, s["rating_key"]):
                        sm = SeasonMapping.query.filter_by(plex_rating_key=s["rating_key"], plex_season_index=season["season_index"]).first()
                        if not sm:
                            sm = SeasonMapping(plex_rating_key=s["rating_key"], plex_season_index=season["season_index"], statut="non_lie")
                            db.session.add(sm)
                        sm.plex_season_rating_key = season.get("rating_key")
                        sm.titre_plex = s["titre"]
                        sm.titre_saison = season.get("titre")
                    db.session.commit()
                except plex_client.PlexError:
                    pass
                self._set(skipped_manuel=self.status()["skipped_manuel"] + 1,
                           done=self.status()["done"] + 1)
                continue

            m = existing or Mapping(titre_plex=s["titre"])
            is_new = existing is None
            m.plex_rating_key = s["rating_key"]
            m.plex_thumb = s.get("thumb")
            m.plex_year = s.get("annee")
            m.tvdb_id = s.get("tvdb_id")
            m.library_id_plex = s["library_id_plex"]

            # Scan Plex uniquement : aucune recherche ni association AniList automatique.
            # Les liens AniList déjà choisis manuellement sont préservés.
            if not existing:
                m.statut = "non_lie"
                db.session.add(m)
            db.session.commit()

            # Indexe également les saisons pour permettre un mapping saison par saison.
            try:
                seasons = plex_client.list_seasons(plex_url, plex_token, s["rating_key"])
                for season in seasons:
                    sm = SeasonMapping.query.filter_by(
                        plex_rating_key=s["rating_key"],
                        plex_season_index=season["season_index"],
                    ).first()
                    if not sm:
                        sm = SeasonMapping(
                            plex_rating_key=s["rating_key"],
                            plex_season_index=season["season_index"],
                            titre_plex=s["titre"],
                            titre_saison=season.get("titre"),
                            statut="non_lie",
                        )
                        db.session.add(sm)
                    sm.plex_season_rating_key = season.get("rating_key")
                    sm.titre_plex = s["titre"]
                    sm.titre_saison = season.get("titre")
                db.session.commit()
            except plex_client.PlexError:
                # L'indexation des saisons ne doit pas faire échouer le scan de la série.
                pass

            counts = self.status()
            self._set(
                created=counts["created"] + (1 if is_new else 0),
                updated=counts["updated"] + (0 if is_new else 1),
                done=counts["done"] + 1,
            )

        # Nettoyage : une série qui n'existe plus dans Plex est retirée de la
        # base, mais uniquement pour les bibliothèques dont le scan a réussi.
        # Les bibliothèques en erreur sont volontairement laissées intactes.
        if successful_library_ids:
            stale = (Mapping.query
                     .filter(Mapping.library_id_plex.in_(successful_library_ids))
                     .all())
            deleted = 0
            for m in stale:
                if str(m.plex_rating_key or "") in seen_rating_keys:
                    continue
                for sm in SeasonMapping.query.filter_by(plex_rating_key=m.plex_rating_key).all():
                    SeasonSyncTarget.query.filter_by(season_mapping_id=sm.id).delete(synchronize_session=False)
                SeasonMapping.query.filter_by(plex_rating_key=m.plex_rating_key).delete(synchronize_session=False)
                db.session.delete(m)
                deleted += 1
            if deleted:
                db.session.commit()
            self._set(deleted=deleted)



# Instance globale (créée dans app.py, comme le SyncWorker)
scanner = None


class MappingAutomation(threading.Thread):
    """Planificateur des scans Plex et des liaisons AniList automatiques par saison."""

    def __init__(self, app, scanner):
        super().__init__(daemon=True)
        self.app = app
        self.scanner = scanner
        self._stop_event = threading.Event()
        self._last_scan = 0.0
        self._last_link = 0.0
        self._last_status = {"scan": None, "link": None, "error": None}

    def stop(self):
        self._stop_event.set()

    def status(self):
        return dict(self._last_status)

    def run(self):
        # Vérification légère toutes les 30 secondes pour que les changements
        # de paramètres soient pris en compte sans redémarrer l'application.
        while not self._stop_event.is_set():
            try:
                with self.app.app_context():
                    now = time.time()
                    scan_enabled = Setting.get("auto_scan_enabled", "0") == "1"
                    link_enabled = Setting.get("auto_link_enabled", "0") == "1"
                    scan_hours = max(1, int(float(Setting.get("auto_scan_interval_hours", "6") or 6)))
                    link_hours = max(1, int(float(Setting.get("auto_link_interval_hours", "6") or 6)))

                    if scan_enabled and now - self._last_scan >= scan_hours * 3600:
                        if self.scanner.start():
                            self._last_scan = now
                            self._last_status["scan"] = time.strftime("%Y-%m-%d %H:%M:%S")

                    # Ne lance pas le lien automatique pendant qu'un scan est actif.
                    if link_enabled and not self.scanner.status().get("running") and now - self._last_link >= link_hours * 3600:
                        self._auto_link()
                        self._last_link = now
                        self._last_status["link"] = time.strftime("%Y-%m-%d %H:%M:%S")
            except Exception as exc:
                self._last_status["error"] = f"{type(exc).__name__}: {exc}"
            self._stop_event.wait(30)

    def _auto_link(self):
        token = Setting.get("anilist_token", "")
        if not token:
            # Une recherche publique peut fonctionner sans token, donc on ne
            # bloque pas ici. Le token reste recommandé pour une utilisation régulière.
            token = None

        # Les liaisons automatiques suivent aussi les saisons Plex nouvellement détectées.
        seasons = (SeasonMapping.query
                   .filter(SeasonMapping.anilist_id.is_(None))
                   .filter(SeasonMapping.statut != "ignore")
                   .order_by(SeasonMapping.titre_plex.asc(), SeasonMapping.plex_season_index.asc())
                   .limit(500).all())
        for season in seasons:
            try:
                candidate, confident = _best_season_match(
                    season.titre_plex, season.plex_season_index, season.titre_saison, token
                )
                if candidate:
                    season.anilist_id = int(candidate["id"])
                    season.titre_anilist = candidate.get("title")
                    season.image_anilist = candidate.get("image")
                    season.statut = "auto" if confident else "a_verifier"
                else:
                    season.statut = "introuvable"
                db.session.commit()
            except anilist_client.AniListError:
                db.session.rollback()
            finally:
                time.sleep(ANILIST_THROTTLE_SECONDS)

"""
Modèles SQLAlchemy pour PlexAniList Dashboard.

- Library : bibliothèques Plex détectées (toggle actif / inactif).
- Mapping : association entre un titre Plex et un anime AniList.
- SyncHistory : log de chaque tentative de synchronisation.
- Setting : clé / valeur (équivalent d'une mini-table de configuration persistante).
"""

from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Library(db.Model):
    __tablename__ = "libraries"

    id = db.Column(db.Integer, primary_key=True)
    id_plex = db.Column(db.String(64), unique=True, nullable=False)  # identifiant numérique de la section Plex
    nom = db.Column(db.String(255), nullable=False)
    activee = db.Column(db.Boolean, default=True, nullable=False)
    type = db.Column(db.String(32), nullable=True)  # "show", "movie", ... (donné par Plex)

    def to_dict(self):
        return {
            "id": self.id,
            "id_plex": self.id_plex,
            "nom": self.nom,
            "activee": self.activee,
            "type": self.type,
        }


class Mapping(db.Model):
    __tablename__ = "mappings"

    id = db.Column(db.Integer, primary_key=True)
    titre_plex = db.Column(db.String(255), unique=True, nullable=False)
    anilist_id = db.Column(db.Integer, nullable=True)
    titre_anilist = db.Column(db.String(255), nullable=True)
    image_anilist = db.Column(db.String(512), nullable=True)
    # auto = trouvé automatiquement (match fiable), manuel = choisi par l'utilisateur,
    # a_verifier = un candidat a été trouvé mais le titre ne correspond pas exactement,
    # introuvable = recherche AniList n'a rien donné,
    # ignore = l'utilisateur a choisi d'exclure ce titre de la synchronisation
    statut = db.Column(db.String(20), default="introuvable", nullable=False)

    # Métadonnées Plex (remplies par le scanner de bibliothèque)
    plex_rating_key = db.Column(db.String(64), nullable=True)   # id interne Plex de la série
    plex_thumb = db.Column(db.String(512), nullable=True)       # chemin relatif de la miniature
    plex_year = db.Column(db.Integer, nullable=True)
    tvdb_id = db.Column(db.Integer, nullable=True)
    library_id_plex = db.Column(db.String(64), nullable=True)   # section Plex d'origine

    # Dernier épisode réellement envoyé à AniList pour ce titre : évite de
    # renvoyer la même mutation à chaque poll tant que l'utilisateur reste sur
    # le même épisode (ex: en pause au-dessus du seuil).
    dernier_episode_sync = db.Column(db.Integer, nullable=True)

    def to_dict(self):
        return {
            "id": self.id,
            "titre_plex": self.titre_plex,
            "anilist_id": self.anilist_id,
            "titre_anilist": self.titre_anilist,
            "image_anilist": self.image_anilist,
            "statut": self.statut,
            "plex_rating_key": self.plex_rating_key,
            "plex_thumb": self.plex_thumb,
            "plex_year": self.plex_year,
            "tvdb_id": self.tvdb_id,
            "library_id_plex": self.library_id_plex,
            "dernier_episode_sync": self.dernier_episode_sync,
        }


class SeasonMapping(db.Model):
    """Association entre une saison Plex et une entrée anime AniList.

    Une série peut donc avoir plusieurs mappings AniList, un par saison.
    """
    __tablename__ = "season_mappings"

    id = db.Column(db.Integer, primary_key=True)
    plex_rating_key = db.Column(db.String(64), nullable=False)
    plex_season_index = db.Column(db.Integer, nullable=False)
    plex_season_rating_key = db.Column(db.String(64), nullable=True)
    titre_plex = db.Column(db.String(255), nullable=False)
    titre_saison = db.Column(db.String(255), nullable=True)
    anilist_id = db.Column(db.Integer, nullable=True)
    titre_anilist = db.Column(db.String(255), nullable=True)
    image_anilist = db.Column(db.String(512), nullable=True)
    statut = db.Column(db.String(20), default="non_lie", nullable=False)
    dernier_episode_sync = db.Column(db.Integer, nullable=True)
    dernier_anilist_id_sync = db.Column(db.Integer, nullable=True)
    anilist_episode_offset = db.Column(db.Integer, nullable=True)
    # Plan de conversion automatique explicite (JSON) : segments Plex -> AniList.
    # Les règles utilisateur restent dans MappingRule et ont toujours priorité.
    conversion_plan = db.Column(db.Text, nullable=True)
    conversion_confidence = db.Column(db.String(20), nullable=True)
    conversion_reason = db.Column(db.String(500), nullable=True)

    __table_args__ = (
        db.UniqueConstraint("plex_rating_key", "plex_season_index", name="uq_plex_season_mapping"),
    )

    def to_dict(self):
        return {
            "id": self.id,
            "plex_rating_key": self.plex_rating_key,
            "plex_season_index": self.plex_season_index,
            "plex_season_rating_key": self.plex_season_rating_key,
            "titre_plex": self.titre_plex,
            "titre_saison": self.titre_saison,
            "anilist_id": self.anilist_id,
            "titre_anilist": self.titre_anilist,
            "image_anilist": self.image_anilist,
            "statut": self.statut,
            "dernier_episode_sync": self.dernier_episode_sync,
            "dernier_anilist_id_sync": self.dernier_anilist_id_sync,
            "anilist_episode_offset": self.anilist_episode_offset,
            "conversion_plan": self.conversion_plan,
            "conversion_confidence": self.conversion_confidence,
            "conversion_reason": self.conversion_reason,
        }


class MappingRule(db.Model):
    """Règle manuelle de conversion des épisodes Plex vers AniList.

    Une règle couvre une plage d'épisodes d'une saison Plex et peut pointer
    vers une entrée AniList différente de celle du mapping principal.
    """
    __tablename__ = "mapping_rules"

    id = db.Column(db.Integer, primary_key=True)
    plex_rating_key = db.Column(db.String(64), nullable=False)
    plex_season_index = db.Column(db.Integer, nullable=False)
    plex_episode_start = db.Column(db.Integer, nullable=False)
    plex_episode_end = db.Column(db.Integer, nullable=False)
    anilist_id = db.Column(db.Integer, nullable=False)
    anilist_episode_start = db.Column(db.Integer, nullable=False, default=1)
    note = db.Column(db.String(500), nullable=True)

    __table_args__ = (
        db.UniqueConstraint(
            "plex_rating_key", "plex_season_index",
            "plex_episode_start", "plex_episode_end",
            name="uq_mapping_rule_range"
        ),
    )

    def to_dict(self):
        return {
            "id": self.id,
            "plex_rating_key": self.plex_rating_key,
            "plex_season_index": self.plex_season_index,
            "plex_episode_start": self.plex_episode_start,
            "plex_episode_end": self.plex_episode_end,
            "anilist_id": self.anilist_id,
            "anilist_episode_start": self.anilist_episode_start,
            "note": self.note or "",
        }


class AniListAccount(db.Model):
    """Compte AniList utilisable comme destination de synchronisation."""
    __tablename__ = "anilist_accounts"

    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), unique=True, nullable=False)
    token = db.Column(db.Text, nullable=False)
    actif = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self, include_token=False):
        data = {"id": self.id, "nom": self.nom, "actif": bool(self.actif)}
        if include_token:
            data["token"] = self.token
        else:
            data["token_configured"] = bool(self.token)
        return data


class SeasonSyncTarget(db.Model):
    """Associe une saison Plex à un ou plusieurs comptes AniList."""
    __tablename__ = "season_sync_targets"

    id = db.Column(db.Integer, primary_key=True)
    season_mapping_id = db.Column(db.Integer, db.ForeignKey("season_mappings.id"), nullable=False)
    anilist_account_id = db.Column(db.Integer, db.ForeignKey("anilist_accounts.id"), nullable=False)
    dernier_episode_sync = db.Column(db.Integer, nullable=True)
    dernier_anilist_id_sync = db.Column(db.Integer, nullable=True)

    season = db.relationship("SeasonMapping", backref=db.backref("sync_targets", cascade="all, delete-orphan"))
    account = db.relationship("AniListAccount")

    __table_args__ = (
        db.UniqueConstraint("season_mapping_id", "anilist_account_id", name="uq_season_sync_target"),
    )

    def to_dict(self):
        return {
            "id": self.id,
            "account_id": self.anilist_account_id,
            "account_name": self.account.nom if self.account else None,
            "anilist_id": self.season.anilist_id if self.season else None,
            "dernier_episode_sync": self.dernier_episode_sync,
            "dernier_anilist_id_sync": self.dernier_anilist_id_sync,
        }


class SyncHistory(db.Model):
    __tablename__ = "sync_history"

    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    titre = db.Column(db.String(255), nullable=False)
    episode = db.Column(db.Integer, nullable=True)
    statut = db.Column(db.String(20), nullable=False)  # succes / erreur
    message = db.Column(db.Text, nullable=True)

    def to_dict(self):
        return {
            "id": self.id,
            "date": self.date.strftime("%Y-%m-%d %H:%M:%S"),
            "titre": self.titre,
            "episode": self.episode,
            "statut": self.statut,
            "message": self.message,
        }


class Setting(db.Model):
    """Table clé/valeur pour la configuration persistante (token Plex, seuil, etc.)."""
    __tablename__ = "settings"

    cle = db.Column(db.String(64), primary_key=True)
    valeur = db.Column(db.Text, nullable=True)

    @classmethod
    def get(cls, cle, default=None):
        s = cls.query.filter_by(cle=cle).first()
        return s.valeur if s else default

    @classmethod
    def set(cls, cle, valeur):
        s = cls.query.filter_by(cle=cle).first()
        if s:
            s.valeur = valeur
        else:
            db.session.add(cls(cle=cle, valeur=valeur))
        db.session.commit()

"""Résolution Plex -> AniList par décalage manuel de la saison."""
from dataclasses import dataclass


@dataclass(frozen=True)
class EpisodeTarget:
    anilist_id: int
    anilist_episode: int
    source: str
    plex_episode: int
    tvdb_absolute_episode: int | None = None
    rule_id: int | None = None
    label: str = ""
    confidence: str = "medium"
    reason: str = ""

    def to_dict(self):
        return {
            "anilist_id": self.anilist_id,
            "anilist_episode": self.anilist_episode,
            "source": self.source,
            "plex_episode": self.plex_episode,
            "tvdb_absolute_episode": self.tvdb_absolute_episode,
            "rule_id": self.rule_id,
            "label": self.label,
            "confidence": self.confidence,
            "reason": self.reason,
        }


def resolve_episode(*, plex_episode, plex_season_index, season_mapping,
                    mapping_rules=(), tvdb_bridge=None, auto_segments=()):
    """Résolution volontairement minimale : numéro Plex + décalage de saison.

    Le décalage est le seul réglage utilisateur de conversion. Sans décalage,
    E1 Plex correspond à E1 AniList. Un résultat <= 0 est invalide.
    Les anciens arguments sont acceptés pour compatibilité avec les appels
    existants, mais ne participent plus à la résolution.
    """
    try:
        plex_episode = int(plex_episode)
        season_index = int(plex_season_index)
    except (TypeError, ValueError):
        return None
    if plex_episode <= 0 or season_index <= 0:
        return None

    anilist_id = getattr(season_mapping, "anilist_id", None)
    if not anilist_id:
        return None

    try:
        offset = int(getattr(season_mapping, "anilist_episode_offset", None) or 0)
    except (TypeError, ValueError):
        offset = 0

    target = plex_episode + offset
    if target <= 0:
        return None

    sign = "+" if offset >= 0 else ""
    label = f"Décalage {sign}{offset}" if offset else "Numérotation identique"
    reason = (
        f"Plex E{plex_episode} + ({offset}) = AniList E{target}."
        if offset
        else f"Aucun décalage : Plex E{plex_episode} = AniList E{target}."
    )
    return EpisodeTarget(
        anilist_id=int(anilist_id),
        anilist_episode=target,
        source="season_offset" if offset else "season_direct",
        plex_episode=plex_episode,
        label=label,
        confidence="high",
        reason=reason,
    )

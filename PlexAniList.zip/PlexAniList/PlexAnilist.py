"""Lance PlexAniList avec son interface Web, sans console Windows visible.

Ce fichier est destiné à être lancé par PlexAniList.vbs avec pythonw.exe.
L'application Flask reste donc accessible dans le navigateur.
"""

import runpy
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
runpy.run_path(str(BASE_DIR / "app.py"), run_name="__main__")
